'use client';
import Link from 'next/link';

export const inr = (cents: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(cents / 100);

export const when = (d: string | Date) =>
  new Date(d).toLocaleString('en-IN', {
    weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit',
  });

export function Spinner({ label = 'Loading…' }: { label?: string }) {
  return <p className="py-16 text-center text-sm text-muted">{label}</p>;
}

export function ErrorBox({ message, retry }: { message: string; retry?: () => void }) {
  return (
    <div className="card border-red-500/40 bg-red-500/5 p-4 text-sm text-red-300">
      <p>{message}</p>
      {retry && (
        <button onClick={retry} className="btn-ghost mt-3 !py-1 !px-3">Try again</button>
      )}
    </div>
  );
}

export function Countdown({ secondsLeft }: { secondsLeft: number }) {
  const m = Math.floor(Math.max(0, secondsLeft) / 60);
  const s = Math.max(0, secondsLeft) % 60;
  const urgent = secondsLeft <= 60;
  return (
    <span className={`font-mono text-lg font-bold ${urgent ? 'text-red-400' : 'text-accent'}`}>
      {m}:{String(s).padStart(2, '0')}
    </span>
  );
}

export function Poster({ url, title, className = '' }: { url?: string | null; title: string; className?: string }) {
  if (url) return <img src={url} alt={title} className={`object-cover ${className}`} />;
  const hue = [...title].reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
  return (
    <div
      className={`flex items-center justify-center p-3 text-center text-xs font-semibold leading-tight text-white/85 ${className}`}
      style={{ background: `linear-gradient(150deg, hsl(${hue} 55% 26%), hsl(${(hue + 48) % 360} 60% 14%))` }}
    >
      {title}
    </div>
  );
}

export function Empty({ title, hint, href, cta }: { title: string; hint?: string; href?: string; cta?: string }) {
  return (
    <div className="card p-10 text-center">
      <p className="font-semibold">{title}</p>
      {hint && <p className="mt-1 text-sm text-muted">{hint}</p>}
      {href && cta && (
        <Link href={href} className="btn-primary mt-5">{cta}</Link>
      )}
    </div>
  );
}
