'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

type Me = { id: string; name: string; email: string; role: 'CUSTOMER' | 'ORGANISER' | 'ADMIN' } | null;

export default function Nav() {
  const [me, setMe] = useState<Me>(null);
  const [ready, setReady] = useState(false);
  const router = useRouter();

  useEffect(() => {
    fetch('/api/auth/me')
      .then((r) => r.json())
      .then((d) => setMe(d.user))
      .finally(() => setReady(true));
  }, []);

  async function logout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    setMe(null);
    router.push('/');
    router.refresh();
  }

  return (
    <header className="sticky top-0 z-30 border-b border-line bg-ink/85 backdrop-blur">
      <div className="mx-auto flex w-full max-w-6xl items-center gap-4 px-4 py-3">
        <Link href="/" className="text-lg font-extrabold tracking-wide text-accent">
          TIKTO
        </Link>
        <nav className="flex flex-1 items-center gap-1 text-sm">
          <Link href="/" className="rounded px-3 py-1.5 text-slate-300 hover:bg-line">Browse</Link>
          {me && <Link href="/bookings" className="rounded px-3 py-1.5 text-slate-300 hover:bg-line">My bookings</Link>}
          {me && <Link href="/waitlist" className="rounded px-3 py-1.5 text-slate-300 hover:bg-line">Waitlist</Link>}
          {me && (me.role === 'ORGANISER' || me.role === 'ADMIN') && (
            <Link href="/organiser" className="rounded px-3 py-1.5 text-slate-300 hover:bg-line">Organiser</Link>
          )}
          {me?.role === 'ADMIN' && (
            <Link href="/admin/venues" className="rounded px-3 py-1.5 text-slate-300 hover:bg-line">Venues</Link>
          )}
        </nav>
        {ready &&
          (me ? (
            <div className="flex items-center gap-3">
              <span className="hidden text-xs text-muted sm:block">
                {me.name} · <span className="text-accent">{me.role.toLowerCase()}</span>
              </span>
              <button onClick={logout} className="btn-ghost !py-1.5 !px-3">Sign out</button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link href="/login" className="btn-ghost !py-1.5 !px-3">Sign in</Link>
              <Link href="/register" className="btn-primary !py-1.5 !px-3">Create account</Link>
            </div>
          ))}
      </div>
    </header>
  );
}
