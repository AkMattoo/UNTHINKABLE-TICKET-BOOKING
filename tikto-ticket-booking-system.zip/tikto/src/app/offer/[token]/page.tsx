'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import { Countdown, ErrorBox, Poster, Spinner, inr, when } from '@/components/ui';

type Offer = {
  token: string; showId: string; expiresAt: string; secondsLeft: number;
  seat: string; seatId: string; categoryName: string; priceCents: number;
  customer: { name: string; email: string };
  show: { title: string; posterUrl: string | null; startsAt: string; screen: string; venue: string };
};

export default function OfferPage({ params }: { params: { token: string } }) {
  const router = useRouter();
  const [offer, setOffer] = useState<Offer | null>(null);
  const [error, setError] = useState('');
  const [left, setLeft] = useState(0);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const d = await fetch(`/api/offers/${params.token}`, { cache: 'no-store' }).then((r) => r.json());
    if (d.error) return setError(d.error);
    setOffer(d.offer);
    setLeft(d.offer.secondsLeft);
  }, [params.token]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    const t = setInterval(() => setLeft((s) => Math.max(0, s - 1)), 1000);
    const sync = setInterval(load, 20000);
    return () => {
      clearInterval(t);
      clearInterval(sync);
    };
  }, [load]);

  async function claim() {
    setBusy(true);
    setError('');
    const res = await fetch(`/api/offers/${params.token}/claim`, { method: 'POST' });
    const data = await res.json();
    setBusy(false);
    if (res.status === 401) return router.push(`/login?next=/offer/${params.token}`);
    if (!res.ok) return setError(data.error ?? 'Could not claim this seat');
    router.push(`/bookings?highlight=${data.booking.reference}`);
  }

  if (error && !offer)
    return (
      <div className="mx-auto max-w-lg space-y-4">
        <ErrorBox message={error} />
        <Link href="/" className="btn-ghost">Browse other shows</Link>
      </div>
    );
  if (!offer) return <Spinner label="Checking your offer…" />;

  return (
    <div className="mx-auto max-w-xl space-y-5">
      <div className="card border-accent/50 p-5 text-center">
        <p className="text-xs uppercase tracking-widest text-accent">Waitlist offer</p>
        <h1 className="mt-2 text-2xl font-bold">A seat opened up for you</h1>
        <p className="mt-1 text-sm text-muted">
          Hi {offer.customer.name} — seat <b className="text-slate-200">{offer.seat}</b> ({offer.categoryName}) is
          reserved for you alone. If the timer runs out it passes to the next person in the queue.
        </p>
        <div className="mt-4 flex items-center justify-center gap-2">
          <span className="text-xs text-muted">Time to claim</span>
          <Countdown secondsLeft={left} />
        </div>
      </div>

      <div className="card flex gap-4 overflow-hidden p-4">
        <Poster url={offer.show.posterUrl} title={offer.show.title} className="h-28 w-20 shrink-0 rounded-lg" />
        <div>
          <h2 className="font-bold">{offer.show.title}</h2>
          <p className="text-sm text-muted">{offer.show.venue} · {offer.show.screen}</p>
          <p className="text-sm text-muted">{when(offer.show.startsAt)}</p>
          <p className="mt-2 font-semibold text-accent">{inr(offer.priceCents)}</p>
        </div>
      </div>

      {error && <ErrorBox message={error} />}

      <button onClick={claim} disabled={busy || left <= 0} className="btn-primary w-full">
        {left <= 0 ? 'Offer expired' : busy ? 'Confirming…' : `Claim seat ${offer.seat} for ${inr(offer.priceCents)}`}
      </button>
      <p className="text-center text-xs text-muted">
        Signed in as the waitlisted customer? Claiming issues the booking and emails your QR ticket immediately.
      </p>
    </div>
  );
}
