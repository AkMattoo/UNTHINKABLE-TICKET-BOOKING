'use client';
import { useCallback, useEffect, useState } from 'react';
import { ErrorBox, Spinner } from '@/components/ui';

type Venue = {
  id: string; name: string; city: string; address: string;
  categories: { id: string; name: string; colour: string; rank: number }[];
  _count: { seats: number; shows: number };
};

const BLANK_ROWS = 'A:14:Standard\nB:14:Standard\nC:16:Premium\nD:16:Premium\nE:12:Recliner';

export default function AdminVenuesPage() {
  const [venues, setVenues] = useState<Venue[] | null>(null);
  const [error, setError] = useState('');
  const [flash, setFlash] = useState('');
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    name: '', city: '', address: '',
    categories: 'Recliner:#c084fc\nPremium:#f5c518\nStandard:#4f7cff',
    rows: BLANK_ROWS,
    aisleAfter: '4,12',
  });

  const load = useCallback(() => {
    fetch('/api/venues')
      .then((r) => r.json())
      .then((d) => (d.error ? setError(d.error) : setVenues(d.venues)));
  }, []);

  useEffect(load, [load]);

  async function create(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError('');
    setFlash('');
    const categories = form.categories
      .split('\n').map((l) => l.trim()).filter(Boolean)
      .map((l, i) => {
        const [name, colour] = l.split(':');
        return { name: name.trim(), colour: (colour ?? '#4f7cff').trim(), rank: i };
      });
    const aisleAfter = form.aisleAfter.split(',').map((n) => Number(n.trim())).filter((n) => n > 0);
    const rows = form.rows
      .split('\n').map((l) => l.trim()).filter(Boolean)
      .map((l) => {
        const [rowLabel, seats, category] = l.split(':');
        return { rowLabel: rowLabel.trim(), seats: Number(seats), category: category.trim(), aisleAfter };
      });

    const res = await fetch('/api/venues', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: form.name, city: form.city, address: form.address, categories, rows }),
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) return setError(data.error ?? 'Could not create the venue');
    setFlash(`Created ${data.venue.name} with ${data.seatsCreated} seats.`);
    setForm({ ...form, name: '', city: '', address: '' });
    load();
  }

  return (
    <div className="space-y-5">
      <h1 className="text-xl font-bold">Venues & seat layouts</h1>

      <form onSubmit={create} className="card space-y-3 p-5">
        <h2 className="text-sm font-semibold">Add a venue</h2>
        <div className="grid gap-3 sm:grid-cols-3">
          <div><label className="label">Name</label><input className="input" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div><label className="label">City</label><input className="input" required value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></div>
          <div><label className="label">Address</label><input className="input" required value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          <div>
            <label className="label">Categories — one per line, <code>Name:#colour</code></label>
            <textarea className="input h-28 font-mono text-xs" value={form.categories} onChange={(e) => setForm({ ...form, categories: e.target.value })} />
          </div>
          <div>
            <label className="label">Rows — <code>Label:seats:Category</code></label>
            <textarea className="input h-28 font-mono text-xs" value={form.rows} onChange={(e) => setForm({ ...form, rows: e.target.value })} />
          </div>
          <div>
            <label className="label">Aisle after seat numbers</label>
            <input className="input font-mono text-xs" value={form.aisleAfter} onChange={(e) => setForm({ ...form, aisleAfter: e.target.value })} />
            <p className="mt-2 text-[11px] text-muted">Comma separated. Renders a gap in the grid, keeps seat numbering continuous.</p>
          </div>
        </div>
        {error && <p className="text-sm text-red-400">{error}</p>}
        {flash && <p className="text-sm text-emerald-400">{flash}</p>}
        <button className="btn-primary" disabled={busy}>{busy ? 'Creating…' : 'Create venue'}</button>
      </form>

      {!venues ? (
        <Spinner />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {venues.map((v) => (
            <div key={v.id} className="card p-4">
              <p className="font-semibold">{v.name}</p>
              <p className="text-xs text-muted">{v.address}</p>
              <p className="mt-2 text-sm text-muted">
                {v._count.seats} seats · {v._count.shows} shows
              </p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {v.categories.map((c) => (
                  <span key={c.id} className="chip !py-0.5 !px-2">
                    <i className="h-2 w-2 rounded-full" style={{ background: c.colour }} />
                    {c.name}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
