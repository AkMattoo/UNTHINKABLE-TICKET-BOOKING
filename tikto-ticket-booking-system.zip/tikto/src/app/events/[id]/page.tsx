'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { ErrorBox, Poster, Spinner, inr, when } from '@/components/ui';

type Show = {
  id: string; startsAt: string; screen: string;
  venue: { id: string; name: string; city: string; address: string };
  prices: { categoryId: string; priceCents: number }[];
  totalSeats: number; availableSeats: number; soldOut: boolean;
};
type EventDetail = {
  id: string; title: string; description: string; posterUrl: string | null; type: string;
  language: string; genre: string; durationMin: number; certificate: string;
  organiser: { name: string }; shows: Show[];
};

export default function EventPage({ params }: { params: { id: string } }) {
  const [event, setEvent] = useState<EventDetail | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch(`/api/events/${params.id}`)
      .then((r) => r.json())
      .then((d) => (d.error ? setError(d.error) : setEvent(d.event)))
      .catch(() => setError('Could not load this event'));
  }, [params.id]);

  if (error) return <ErrorBox message={error} />;
  if (!event) return <Spinner />;

  const byDay = event.shows.reduce<Record<string, Show[]>>((acc, s) => {
    const day = new Date(s.startsAt).toDateString();
    (acc[day] ??= []).push(s);
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <div className="card flex flex-col gap-5 overflow-hidden p-5 sm:flex-row">
        <Poster url={event.posterUrl} title={event.title} className="h-56 w-full rounded-lg sm:w-40" />
        <div className="flex-1 space-y-3">
          <div>
            <h1 className="text-2xl font-bold">{event.title}</h1>
            <p className="mt-1 text-sm text-muted">
              {event.language} · {event.genre} · {event.durationMin} min · {event.certificate}
            </p>
          </div>
          <p className="max-w-2xl text-sm text-slate-300">{event.description}</p>
          <p className="text-xs text-muted">Presented by {event.organiser.name}</p>
        </div>
      </div>

      {Object.entries(byDay).map(([day, shows]) => (
        <section key={day} className="space-y-3">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted">{day}</h2>
          <div className="space-y-3">
            {Object.entries(
              shows.reduce<Record<string, Show[]>>((acc, s) => {
                (acc[s.venue.name] ??= []).push(s);
                return acc;
              }, {}),
            ).map(([venueName, vshows]) => (
              <div key={venueName} className="card p-4">
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <div>
                    <p className="font-semibold">{venueName}</p>
                    <p className="text-xs text-muted">{vshows[0].venue.address}</p>
                  </div>
                  <p className="text-xs text-muted">
                    from {inr(Math.min(...vshows.flatMap((s) => s.prices.map((p) => p.priceCents))))}
                  </p>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {vshows.map((s) => (
                    <Link
                      key={s.id}
                      href={`/shows/${s.id}`}
                      className={`rounded-lg border px-3 py-2 text-sm transition ${
                        s.soldOut
                          ? 'border-red-500/40 text-red-300 hover:bg-red-500/10'
                          : 'border-line text-slate-200 hover:border-accent hover:text-accent'
                      }`}
                    >
                      <span className="font-semibold">
                        {new Date(s.startsAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                      <span className="ml-2 text-[11px] text-muted">
                        {s.soldOut ? 'Sold out — join waitlist' : `${s.availableSeats} left`}
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>
      ))}

      {event.shows.length === 0 && (
        <div className="card p-8 text-center text-sm text-muted">No upcoming shows scheduled.</div>
      )}
      <p className="text-xs text-muted">Times shown in your local timezone. {when(new Date())}</p>
    </div>
  );
}
