'use client';
import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { Empty, ErrorBox, Poster, Spinner, when } from '@/components/ui';

type EventCard = {
  id: string; type: 'MOVIE' | 'CONCERT'; title: string; description: string; posterUrl: string | null;
  language: string; genre: string; durationMin: number; certificate: string;
  cities: string[]; showCount: number;
  nextShow: { id: string; startsAt: string; venue: { name: string; city: string } } | null;
};

export default function BrowsePage() {
  const [events, setEvents] = useState<EventCard[] | null>(null);
  const [error, setError] = useState('');
  const [q, setQ] = useState('');
  const [type, setType] = useState('');
  const [city, setCity] = useState('');
  const [date, setDate] = useState('');

  const query = useMemo(() => {
    const p = new URLSearchParams();
    if (q) p.set('q', q);
    if (type) p.set('type', type);
    if (city) p.set('city', city);
    if (date) p.set('date', date);
    return p.toString();
  }, [q, type, city, date]);

  useEffect(() => {
    const t = setTimeout(() => {
      setError('');
      fetch(`/api/events?${query}`)
        .then((r) => r.json())
        .then((d) => (d.error ? setError(d.error) : setEvents(d.events)))
        .catch(() => setError('Could not load events'));
    }, 200);
    return () => clearTimeout(t);
  }, [query]);

  const cities = useMemo(
    () => [...new Set((events ?? []).flatMap((e) => e.cities))].sort(),
    [events],
  );

  return (
    <div className="space-y-6">
      <section className="card overflow-hidden p-6">
        <h1 className="text-2xl font-bold">What are you watching?</h1>
        <p className="mt-1 text-sm text-muted">
          Pick your seats on a live map. Held seats release automatically, and sold-out shows have a waitlist that
          assigns itself.
        </p>
        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <input className="input" placeholder="Search title or genre…" value={q} onChange={(e) => setQ(e.target.value)} />
          <select className="input" value={type} onChange={(e) => setType(e.target.value)}>
            <option value="">All types</option>
            <option value="MOVIE">Movies</option>
            <option value="CONCERT">Concerts</option>
          </select>
          <select className="input" value={city} onChange={(e) => setCity(e.target.value)}>
            <option value="">All cities</option>
            {cities.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          <input type="date" className="input" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>
      </section>

      {error && <ErrorBox message={error} />}
      {!events && !error && <Spinner />}
      {events?.length === 0 && <Empty title="Nothing matches those filters" hint="Try clearing the date or city." />}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {events?.map((e) => (
          <Link key={e.id} href={`/events/${e.id}`} className="card group overflow-hidden transition hover:border-accent/50">
            <Poster url={e.posterUrl} title={e.title} className="h-52 w-full" />
            <div className="space-y-2 p-4">
              <div className="flex items-start justify-between gap-2">
                <h2 className="font-semibold leading-tight group-hover:text-accent">{e.title}</h2>
                <span className="chip shrink-0 !px-2 !py-0.5">{e.certificate}</span>
              </div>
              <p className="text-xs text-muted">
                {e.language} · {e.genre || (e.type === 'CONCERT' ? 'Live' : 'Drama')} · {e.durationMin} min
              </p>
              <p className="line-clamp-2 text-xs text-slate-400">{e.description}</p>
              <div className="flex items-center justify-between pt-1 text-xs">
                <span className="text-muted">{e.cities.join(', ')}</span>
                <span className="text-accent">{e.showCount} show{e.showCount === 1 ? '' : 's'}</span>
              </div>
              {e.nextShow && (
                <p className="text-[11px] text-muted">Next: {when(e.nextShow.startsAt)} · {e.nextShow.venue.name}</p>
              )}
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
