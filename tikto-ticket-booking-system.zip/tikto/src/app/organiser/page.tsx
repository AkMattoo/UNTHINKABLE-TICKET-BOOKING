'use client';
import { useCallback, useEffect, useState } from 'react';
import { ErrorBox, Spinner, inr, when } from '@/components/ui';

type ShowRow = {
  id: string; startsAt: string; screen: string; venue: string; city: string;
  capacity: number; seatsSold: number; bookings: number; revenueCents: number;
};
type EventRow = {
  id: string; title: string; type: string; shows: ShowRow[];
  totalRevenueCents: number; totalSeatsSold: number;
};
type Summary = {
  show: { title: string; startsAt: string; venue: string; screen: string };
  totals: {
    capacity: number; seatsSold: number; occupancyPct: number; grossRevenueCents: number;
    refundedCents: number; bookings: number; cancellations: number;
    waitlistDepth: number; waitlistConversions: number;
  };
  byCategory: {
    category: string; priceCents: number; total: number; sold: number; held: number; offered: number;
    available: number; revenueCents: number; waitlistWaiting: number; waitlistOffered: number; waitlistConverted: number;
  }[];
};

export default function OrganiserPage() {
  const [events, setEvents] = useState<EventRow[] | null>(null);
  const [error, setError] = useState('');
  const [openShow, setOpenShow] = useState<string | null>(null);
  const [summary, setSummary] = useState<Summary | null>(null);

  const load = useCallback(() => {
    fetch('/api/organiser/events')
      .then((r) => r.json())
      .then((d) => (d.error ? setError(d.error) : setEvents(d.events)))
      .catch(() => setError('Could not load your events'));
  }, []);

  useEffect(load, [load]);

  useEffect(() => {
    if (!openShow) return setSummary(null);
    setSummary(null);
    fetch(`/api/organiser/shows/${openShow}/summary`)
      .then((r) => r.json())
      .then((d) => !d.error && setSummary(d));
  }, [openShow]);

  if (error && !events) return <ErrorBox message={`${error} — sign in as an organiser.`} />;
  if (!events) return <Spinner />;

  const gross = events.reduce((t, e) => t + e.totalRevenueCents, 0);
  const sold = events.reduce((t, e) => t + e.totalSeatsSold, 0);

  return (
    <div className="space-y-5">
      <div className="grid gap-3 sm:grid-cols-3">
        {[
          ['Gross revenue', inr(gross)],
          ['Seats sold', String(sold)],
          ['Live events', String(events.length)],
        ].map(([k, v]) => (
          <div key={k} className="card p-4">
            <p className="text-xs text-muted">{k}</p>
            <p className="mt-1 text-2xl font-bold text-accent">{v}</p>
          </div>
        ))}
      </div>

      {events.map((e) => (
        <section key={e.id} className="card p-4">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <h2 className="font-bold">
              {e.title} <span className="ml-2 chip !py-0.5 !px-2">{e.type.toLowerCase()}</span>
            </h2>
            <p className="text-sm text-muted">
              {e.totalSeatsSold} seats · <span className="font-semibold text-accent">{inr(e.totalRevenueCents)}</span>
            </p>
          </div>

          <div className="mt-3 overflow-x-auto">
            <table className="w-full min-w-[640px] text-sm">
              <thead className="text-left text-xs uppercase tracking-wide text-muted">
                <tr>
                  <th className="pb-2 font-medium">Show</th>
                  <th className="pb-2 font-medium">Venue</th>
                  <th className="pb-2 text-right font-medium">Occupancy</th>
                  <th className="pb-2 text-right font-medium">Bookings</th>
                  <th className="pb-2 text-right font-medium">Revenue</th>
                  <th className="pb-2" />
                </tr>
              </thead>
              <tbody>
                {e.shows.map((s) => (
                  <tr key={s.id} className="border-t border-line">
                    <td className="py-2">{when(s.startsAt)} · {s.screen}</td>
                    <td className="py-2 text-muted">{s.venue}, {s.city}</td>
                    <td className="py-2 text-right">
                      {s.seatsSold}/{s.capacity}
                      <span className="ml-1 text-xs text-muted">
                        ({s.capacity ? Math.round((s.seatsSold / s.capacity) * 100) : 0}%)
                      </span>
                    </td>
                    <td className="py-2 text-right">{s.bookings}</td>
                    <td className="py-2 text-right font-semibold text-accent">{inr(s.revenueCents)}</td>
                    <td className="py-2 text-right">
                      <button
                        onClick={() => setOpenShow(openShow === s.id ? null : s.id)}
                        className="btn-ghost !py-1 !px-2 text-xs"
                      >
                        {openShow === s.id ? 'Hide' : 'Details'}
                      </button>
                    </td>
                  </tr>
                ))}
                {e.shows.length === 0 && (
                  <tr><td colSpan={6} className="py-4 text-center text-muted">No shows scheduled.</td></tr>
                )}
              </tbody>
            </table>
          </div>

          {openShow && e.shows.some((s) => s.id === openShow) && (
            <div className="mt-4 rounded-lg border border-line p-4">
              {!summary ? (
                <Spinner label="Loading breakdown…" />
              ) : (
                <>
                  <div className="grid gap-3 sm:grid-cols-4">
                    {[
                      ['Occupancy', `${summary.totals.occupancyPct}%`],
                      ['Refunded', inr(summary.totals.refundedCents)],
                      ['Waitlist depth', String(summary.totals.waitlistDepth)],
                      ['Waitlist conversions', String(summary.totals.waitlistConversions)],
                    ].map(([k, v]) => (
                      <div key={k}>
                        <p className="text-xs text-muted">{k}</p>
                        <p className="text-lg font-semibold">{v}</p>
                      </div>
                    ))}
                  </div>
                  <table className="mt-4 w-full text-sm">
                    <thead className="text-left text-xs uppercase text-muted">
                      <tr>
                        <th className="pb-2 font-medium">Category</th>
                        <th className="pb-2 text-right font-medium">Price</th>
                        <th className="pb-2 text-right font-medium">Sold</th>
                        <th className="pb-2 text-right font-medium">Held</th>
                        <th className="pb-2 text-right font-medium">Offered</th>
                        <th className="pb-2 text-right font-medium">Free</th>
                        <th className="pb-2 text-right font-medium">Queue</th>
                        <th className="pb-2 text-right font-medium">Revenue</th>
                      </tr>
                    </thead>
                    <tbody>
                      {summary.byCategory.map((c) => (
                        <tr key={c.category} className="border-t border-line">
                          <td className="py-2">{c.category}</td>
                          <td className="py-2 text-right">{inr(c.priceCents)}</td>
                          <td className="py-2 text-right">{c.sold}</td>
                          <td className="py-2 text-right text-orange-300">{c.held}</td>
                          <td className="py-2 text-right text-purple-300">{c.offered}</td>
                          <td className="py-2 text-right">{c.available}</td>
                          <td className="py-2 text-right">{c.waitlistWaiting}</td>
                          <td className="py-2 text-right font-semibold text-accent">{inr(c.revenueCents)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </>
              )}
            </div>
          )}
        </section>
      ))}
    </div>
  );
}
