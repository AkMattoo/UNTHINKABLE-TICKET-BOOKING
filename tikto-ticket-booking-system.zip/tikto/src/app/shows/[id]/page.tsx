'use client';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ErrorBox, Spinner, inr, when } from '@/components/ui';

type SeatCell = {
  seatId: string; rowLabel: string; seatNumber: number; gridRow: number; gridCol: number;
  categoryId: string; priceCents: number;
  state: 'AVAILABLE' | 'HELD' | 'OFFERED' | 'BOOKED' | 'BLOCKED';
};
type Category = { id: string; name: string; colour: string; priceCents: number; total: number; available: number };
type SeatMap = {
  show: { id: string; screen: string; startsAt: string; event: { title: string; certificate: string; durationMin: number }; venue: { name: string; city: string } };
  categories: Category[]; seats: SeatCell[]; soldOut: boolean; availableCount: number; generatedAt: string;
};

const POLL_MS = 4000;

export default function SeatMapPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [map, setMap] = useState<SeatMap | null>(null);
  const [error, setError] = useState('');
  const [selected, setSelected] = useState<string[]>([]);
  const [holding, setHolding] = useState(false);
  const [notice, setNotice] = useState('');
  const [waitlistBusy, setWaitlistBusy] = useState('');
  const [myQueue, setMyQueue] = useState<{ categoryId: string; position: number | null; status: string }[]>([]);
  const selectedRef = useRef<string[]>([]);
  selectedRef.current = selected;

  const load = useCallback(async () => {
    const res = await fetch(`/api/shows/${params.id}/seatmap`, { cache: 'no-store' });
    const data = await res.json();
    if (data.error) return setError(data.error);
    setMap(data);
    // Drop any selection that somebody else has taken since the last poll.
    const takeable = new Set(data.seats.filter((s: SeatCell) => s.state === 'AVAILABLE').map((s: SeatCell) => s.seatId));
    const survivors = selectedRef.current.filter((id) => takeable.has(id));
    if (survivors.length !== selectedRef.current.length) {
      setSelected(survivors);
      setNotice('Some of your selected seats were just taken by another customer.');
    }
  }, [params.id]);

  useEffect(() => {
    load();
    const t = setInterval(load, POLL_MS);
    return () => clearInterval(t);
  }, [load]);

  useEffect(() => {
    fetch(`/api/shows/${params.id}/waitlist`)
      .then((r) => r.json())
      .then((d) => d.mine && setMyQueue(d.mine))
      .catch(() => {});
  }, [params.id]);

  const grid = useMemo(() => {
    if (!map) return { rows: [] as { label: string; cells: (SeatCell | null)[] }[], cols: 0 };
    const cols = Math.max(...map.seats.map((s) => s.gridCol), 0);
    const byRow = new Map<number, SeatCell[]>();
    map.seats.forEach((s) => byRow.set(s.gridRow, [...(byRow.get(s.gridRow) ?? []), s]));
    const rows = [...byRow.entries()]
      .sort((a, b) => a[0] - b[0])
      .map(([, cells]) => {
        const line: (SeatCell | null)[] = Array(cols).fill(null);
        cells.forEach((c) => (line[c.gridCol - 1] = c));
        return { label: cells[0].rowLabel, cells: line };
      });
    return { rows, cols };
  }, [map]);

  const total = useMemo(
    () => selected.reduce((t, id) => t + (map?.seats.find((s) => s.seatId === id)?.priceCents ?? 0), 0),
    [selected, map],
  );

  function toggle(seat: SeatCell) {
    if (seat.state !== 'AVAILABLE') return;
    setNotice('');
    setSelected((cur) =>
      cur.includes(seat.seatId)
        ? cur.filter((s) => s !== seat.seatId)
        : cur.length >= 10
          ? (setNotice('You can book at most 10 seats in one go.'), cur)
          : [...cur, seat.seatId],
    );
  }

  async function proceed() {
    setHolding(true);
    setNotice('');
    const res = await fetch(`/api/shows/${params.id}/hold`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ seatIds: selected }),
    });
    const data = await res.json();
    setHolding(false);
    if (res.status === 401) return router.push(`/login?next=/shows/${params.id}`);
    if (!res.ok) {
      setNotice(data.error ?? 'Could not hold those seats');
      setSelected([]);
      return load();
    }
    router.push(`/checkout/${data.holdId}`);
  }

  async function joinWaitlist(categoryId: string) {
    setWaitlistBusy(categoryId);
    const res = await fetch(`/api/shows/${params.id}/waitlist`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ categoryId, quantity: 1 }),
    });
    const data = await res.json();
    setWaitlistBusy('');
    if (res.status === 401) return router.push(`/login?next=/shows/${params.id}`);
    setNotice(res.ok ? `You're #${data.position} in the queue — we'll email you the moment a seat frees up.` : data.error);
    setMyQueue((q) => [...q.filter((m) => m.categoryId !== categoryId), { categoryId, position: data.position, status: 'WAITING' }]);
  }

  if (error) return <ErrorBox message={error} retry={load} />;
  if (!map) return <Spinner label="Loading the seat map…" />;

  return (
    <div className="space-y-5">
      <div className="card flex flex-wrap items-center justify-between gap-3 p-4">
        <div>
          <h1 className="text-xl font-bold">{map.show.event.title}</h1>
          <p className="text-sm text-muted">
            {map.show.venue.name}, {map.show.venue.city} · {map.show.screen} · {when(map.show.startsAt)}
          </p>
        </div>
        <div className="text-right text-xs text-muted">
          <p><span className="text-accent font-semibold">{map.availableCount}</span> seats available</p>
          <p className="mt-0.5">live · refreshes every {POLL_MS / 1000}s</p>
        </div>
      </div>

      {notice && (
        <div className="card border-accent/40 bg-accent/5 p-3 text-sm text-accent">{notice}</div>
      )}

      <div className="grid gap-5 lg:grid-cols-[1fr_300px]">
        <div className="card overflow-x-auto p-5">
          <div className="mx-auto w-fit">
            <div className="screen-curve mb-1 w-full min-w-[420px]" />
            <p className="mb-6 text-center text-[10px] uppercase tracking-[0.3em] text-muted">Screen this way</p>

            <div className="space-y-1.5">
              {grid.rows.map((row) => (
                <div key={row.label} className="flex items-center gap-2">
                  <span className="w-4 text-right text-[10px] text-muted">{row.label}</span>
                  <div className="flex gap-1">
                    {row.cells.map((cell, i) =>
                      cell === null ? (
                        <div key={i} style={{ width: 22, height: 22 }} />
                      ) : (
                        <button
                          key={cell.seatId}
                          title={`${cell.rowLabel}${cell.seatNumber} · ${inr(cell.priceCents)} · ${cell.state.toLowerCase()}`}
                          onClick={() => toggle(cell)}
                          disabled={cell.state !== 'AVAILABLE'}
                          className={`seat ${
                            selected.includes(cell.seatId)
                              ? 'seat-selected'
                              : cell.state === 'AVAILABLE'
                                ? 'seat-available'
                                : cell.state === 'BOOKED'
                                  ? 'seat-booked'
                                  : cell.state === 'BLOCKED'
                                    ? 'seat-blocked'
                                    : 'seat-held'
                          }`}
                        >
                          {cell.seatNumber}
                        </button>
                      ),
                    )}
                  </div>
                  <span className="w-4 text-[10px] text-muted">{row.label}</span>
                </div>
              ))}
            </div>

            <div className="mt-7 flex flex-wrap justify-center gap-4 text-[11px] text-muted">
              <span className="flex items-center gap-1.5"><i className="seat seat-available !w-3 !h-3" /> Available</span>
              <span className="flex items-center gap-1.5"><i className="seat seat-selected !w-3 !h-3" /> Selected</span>
              <span className="flex items-center gap-1.5"><i className="seat seat-held !w-3 !h-3" /> Held by someone</span>
              <span className="flex items-center gap-1.5"><i className="seat seat-booked !w-3 !h-3" /> Booked</span>
            </div>
          </div>
        </div>

        <aside className="space-y-4">
          <div className="card p-4">
            <h3 className="text-sm font-semibold">Categories</h3>
            <ul className="mt-3 space-y-2 text-sm">
              {map.categories.map((c) => {
                const mine = myQueue.find((m) => m.categoryId === c.id);
                return (
                  <li key={c.id} className="rounded-lg border border-line p-2.5">
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-2">
                        <i className="h-2.5 w-2.5 rounded-full" style={{ background: c.colour }} />
                        {c.name}
                      </span>
                      <span className="font-semibold">{inr(c.priceCents)}</span>
                    </div>
                    <p className="mt-1 text-[11px] text-muted">
                      {c.available} of {c.total} free
                    </p>
                    {c.available === 0 &&
                      (mine ? (
                        <p className="mt-2 text-[11px] text-accent">
                          {mine.status === 'OFFERED' ? 'A seat is being held for you — check your email' : `You're #${mine.position} on the waitlist`}
                        </p>
                      ) : (
                        <button
                          onClick={() => joinWaitlist(c.id)}
                          disabled={waitlistBusy === c.id}
                          className="btn-ghost mt-2 w-full !py-1 text-xs"
                        >
                          {waitlistBusy === c.id ? 'Joining…' : 'Join waitlist'}
                        </button>
                      ))}
                  </li>
                );
              })}
            </ul>
          </div>

          <div className="card sticky top-20 p-4">
            <h3 className="text-sm font-semibold">Your selection</h3>
            {selected.length === 0 ? (
              <p className="mt-2 text-xs text-muted">Tap seats on the map to select them.</p>
            ) : (
              <>
                <p className="mt-2 text-sm">
                  {selected
                    .map((id) => map.seats.find((s) => s.seatId === id))
                    .filter(Boolean)
                    .map((s) => `${s!.rowLabel}${s!.seatNumber}`)
                    .sort()
                    .join(', ')}
                </p>
                <div className="mt-3 flex items-center justify-between border-t border-line pt-3 text-sm">
                  <span className="text-muted">{selected.length} seat{selected.length > 1 ? 's' : ''}</span>
                  <span className="font-bold text-accent">{inr(total)}</span>
                </div>
              </>
            )}
            <button onClick={proceed} disabled={selected.length === 0 || holding} className="btn-primary mt-4 w-full">
              {holding ? 'Holding seats…' : 'Hold seats & continue'}
            </button>
            <p className="mt-2 text-[11px] leading-relaxed text-muted">
              Seats are held exclusively for you for 10 minutes. If you don't finish checkout, they go back on sale
              automatically.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}
