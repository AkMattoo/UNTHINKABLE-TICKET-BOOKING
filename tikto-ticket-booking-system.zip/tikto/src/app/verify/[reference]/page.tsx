'use client';
import { useEffect, useState } from 'react';
import { Spinner, when } from '@/components/ui';

type Verify = {
  valid: boolean; reason: string | null; reference: string; holder: string;
  seats: string[]; event: string; venue: string; screen: string; startsAt: string;
};

/** What a gate scanner lands on after reading the ticket QR. */
export default function VerifyPage({ params }: { params: { reference: string } }) {
  const [data, setData] = useState<Verify | null>(null);

  useEffect(() => {
    fetch(`/api/verify/${params.reference}`)
      .then((r) => r.json())
      .then(setData);
  }, [params.reference]);

  if (!data) return <Spinner label="Verifying ticket…" />;

  return (
    <div className="mx-auto max-w-md pt-10">
      <div className={`card p-6 text-center ${data.valid ? 'border-emerald-500/50' : 'border-red-500/50'}`}>
        <div className={`mx-auto flex h-16 w-16 items-center justify-center rounded-full text-3xl ${data.valid ? 'bg-emerald-500/15' : 'bg-red-500/15'}`}>
          {data.valid ? '✓' : '✕'}
        </div>
        <h1 className="mt-4 text-xl font-bold">{data.valid ? 'Valid ticket' : 'Not valid'}</h1>
        {data.reason && <p className="mt-1 text-sm text-red-300">{data.reason}</p>}
        {data.reference && (
          <dl className="mt-6 space-y-2 text-left text-sm">
            {[
              ['Reference', data.reference],
              ['Holder', data.holder],
              ['Event', data.event],
              ['Venue', `${data.venue} · ${data.screen}`],
              ['Starts', when(data.startsAt)],
              ['Seats', data.seats.join(', ') || '—'],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4 border-b border-line pb-2">
                <dt className="text-muted">{k}</dt>
                <dd className="text-right font-medium">{v}</dd>
              </div>
            ))}
          </dl>
        )}
      </div>
    </div>
  );
}
