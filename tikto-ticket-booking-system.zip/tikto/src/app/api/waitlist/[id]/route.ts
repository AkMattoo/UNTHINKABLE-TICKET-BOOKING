import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { HttpError, requireUser } from '@/lib/auth';
import { fail, ok } from '@/lib/http';

/** DELETE /api/waitlist/:id — leave the queue. */
export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await requireUser(req);
    const entry = await prisma.waitlistEntry.findUnique({ where: { id: params.id } });
    if (!entry) throw new HttpError(404, 'Waitlist entry not found');
    if (entry.userId !== session.id && session.role !== 'ADMIN') throw new HttpError(403, 'Not your entry');
    if (entry.status === 'OFFERED')
      throw new HttpError(409, 'You currently hold an offer — let it lapse or claim it first');
    await prisma.waitlistEntry.update({ where: { id: params.id }, data: { status: 'CANCELLED' } });
    return ok({ ok: true });
  } catch (e) {
    return fail(e);
  }
}
