import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireUser } from '@/lib/auth';
import { waitlistPosition } from '@/lib/waitlist';
import { fail, ok } from '@/lib/http';

/** GET /api/waitlist — everything the signed-in customer is queued for. */
export async function GET(req: NextRequest) {
  try {
    const session = await requireUser(req);
    const entries = await prisma.waitlistEntry.findMany({
      where: { userId: session.id },
      orderBy: { createdAt: 'desc' },
      include: { category: true, show: { include: { event: true, venue: true } } },
    });
    return ok({
      entries: await Promise.all(
        entries.map(async (e) => ({
          id: e.id, status: e.status, quantity: e.quantity,
          categoryName: e.category.name,
          position: e.status === 'WAITING' ? await waitlistPosition(e.id) : null,
          offerExpiresAt: e.offerExpiresAt,
          offerToken: e.status === 'OFFERED' ? e.offerToken : null,
          show: {
            id: e.showId, title: e.show.event.title, startsAt: e.show.startsAt,
            venue: `${e.show.venue.name}, ${e.show.venue.city}`,
          },
        })),
      ),
    });
  } catch (e) {
    return fail(e);
  }
}
