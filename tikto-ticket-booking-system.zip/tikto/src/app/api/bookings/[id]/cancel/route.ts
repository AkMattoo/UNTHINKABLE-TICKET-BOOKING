import { NextRequest } from 'next/server';
import { requireUser } from '@/lib/auth';
import { cancelBooking } from '@/lib/bookings';
import { fail, ok } from '@/lib/http';

/**
 * POST /api/bookings/:id/cancel
 * Frees the seats and immediately offers each one to the head of that
 * category's waitlist queue, with a time-limited claim link by email.
 */
export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await requireUser(req);
    const result = await cancelBooking(params.id, { id: session.id, role: session.role });
    return ok(result);
  } catch (e) {
    return fail(e);
  }
}
