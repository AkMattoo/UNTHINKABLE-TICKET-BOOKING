import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { HttpError, requireUser } from '@/lib/auth';
import { fail, ok } from '@/lib/http';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await requireUser(req);
    const b = await prisma.booking.findUnique({
      where: { id: params.id },
      include: { show: { include: { event: true, venue: true } }, showSeats: { include: { seat: true } } },
    });
    if (!b) throw new HttpError(404, 'Booking not found');
    if (b.userId !== session.id && session.role !== 'ADMIN') throw new HttpError(403, 'Not your booking');
    return ok({
      booking: {
        ...b,
        seats: b.showSeats.map((s) => `${s.seat.rowLabel}${s.seat.seatNumber}`).sort(),
      },
    });
  } catch (e) {
    return fail(e);
  }
}
