import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireUser } from '@/lib/auth';
import { confirmBooking } from '@/lib/bookings';
import { fail, ok } from '@/lib/http';

/** GET /api/bookings — the signed-in customer's booking history. */
export async function GET(req: NextRequest) {
  try {
    const session = await requireUser(req);
    const bookings = await prisma.booking.findMany({
      where: { userId: session.id },
      orderBy: { createdAt: 'desc' },
      include: {
        show: { include: { event: true, venue: true } },
        showSeats: { include: { seat: true } },
      },
    });

    // Seat rows are detached on cancellation, so cancelled bookings list no seats.
    return ok({
      bookings: bookings.map((b) => ({
        id: b.id, reference: b.reference, status: b.status, totalCents: b.totalCents,
        seatCount: b.seatCount, createdAt: b.createdAt, qrDataUrl: b.qrDataUrl,
        seats: b.showSeats.map((s) => `${s.seat.rowLabel}${s.seat.seatNumber}`).sort(),
        show: {
          id: b.show.id, startsAt: b.show.startsAt, screen: b.show.screen,
          title: b.show.event.title, posterUrl: b.show.event.posterUrl,
          venue: `${b.show.venue.name}, ${b.show.venue.city}`,
        },
        cancellable: b.status === 'CONFIRMED' && b.show.startsAt.getTime() > Date.now(),
      })),
    });
  } catch (e) {
    return fail(e);
  }
}

const Body = z.object({
  showId: z.string(),
  holdId: z.string(),
  contactName: z.string().min(2),
  contactEmail: z.string().email(),
  contactPhone: z.string().max(20).optional(),
});

/** POST /api/bookings — converts a live hold (or waitlist offer) into a confirmed booking. */
export async function POST(req: NextRequest) {
  try {
    const session = await requireUser(req);
    const body = Body.parse(await req.json());
    const result = await confirmBooking({ userId: session.id, ...body });
    return ok(
      {
        booking: {
          id: result.booking.id,
          reference: result.booking.reference,
          status: result.booking.status,
          totalCents: result.totalCents,
          seats: result.seats,
          qrDataUrl: result.qrDataUrl,
        },
        emailedTo: body.contactEmail,
      },
      201,
    );
  } catch (e) {
    return fail(e);
  }
}
