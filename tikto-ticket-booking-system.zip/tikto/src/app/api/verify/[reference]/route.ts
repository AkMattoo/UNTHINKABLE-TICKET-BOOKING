import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { fail, ok } from '@/lib/http';

export const dynamic = 'force-dynamic';

/** GET /api/verify/:reference — what a gate scanner hits after reading the QR. */
export async function GET(_req: NextRequest, { params }: { params: { reference: string } }) {
  try {
    const b = await prisma.booking.findUnique({
      where: { reference: params.reference },
      include: { show: { include: { event: true, venue: true } }, showSeats: { include: { seat: true } } },
    });
    if (!b) return ok({ valid: false, reason: 'Unknown booking reference' }, 404);
    const valid = b.status === 'CONFIRMED';
    return ok({
      valid,
      reason: valid ? null : `Booking is ${b.status.toLowerCase()}`,
      reference: b.reference,
      holder: b.contactName,
      seats: b.showSeats.map((s) => `${s.seat.rowLabel}${s.seat.seatNumber}`).sort(),
      event: b.show.event.title,
      venue: `${b.show.venue.name}, ${b.show.venue.city}`,
      screen: b.show.screen,
      startsAt: b.show.startsAt,
    });
  } catch (e) {
    return fail(e);
  }
}
