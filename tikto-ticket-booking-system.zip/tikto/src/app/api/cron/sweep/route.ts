import { NextRequest } from 'next/server';
import { env } from '@/lib/env';
import { sweepExpiredHolds } from '@/lib/seats';
import { expireLapsedOffers, offerFreedSeats } from '@/lib/waitlist';
import { prisma } from '@/lib/prisma';
import { fail, ok } from '@/lib/http';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

/**
 * GET|POST /api/cron/sweep
 * Wire this to Vercel Cron (every minute) or an external pinger.
 * Auth: `Authorization: Bearer $CRON_SECRET` or `?secret=$CRON_SECRET`.
 *
 * The sweeper is a housekeeping job, not a correctness dependency: seat reads
 * and seat writes both treat a lapsed lock as free, so a late sweep only means
 * a seat looks taken for a few extra seconds on someone's screen.
 */
async function run(req: NextRequest) {
  const auth = req.headers.get('authorization');
  const secret = req.nextUrl.searchParams.get('secret');
  const authorised = auth === `Bearer ${env.cronSecret}` || secret === env.cronSecret;
  if (!authorised && process.env.NODE_ENV === 'production')
    return ok({ error: 'Unauthorised' }, 401);

  const started = Date.now();

  // 1. Time out lapsed waitlist offers and pass those seats down the queue.
  const offers = await expireLapsedOffers();
  // 2. Release abandoned checkout holds.
  const swept = await sweepExpiredHolds();
  // 3. Any seat now free in a show that still has a queue goes out as an offer.
  let extraOffers = 0;
  if (swept.released > 0) {
    const showsWithQueue = await prisma.waitlistEntry.findMany({
      where: { status: 'WAITING' },
      select: { showId: true },
      distinct: ['showId'],
      take: 50,
    });
    for (const { showId } of showsWithQueue) {
      const free = await prisma.showSeat.findMany({
        where: { showId, state: 'AVAILABLE' },
        select: { seatId: true },
        take: 25,
      });
      extraOffers += await offerFreedSeats(showId, free.map((f) => f.seatId));
    }
  }

  return ok({
    ok: true,
    holdsReleased: swept.released,
    offersExpired: offers.expired,
    offersReissued: offers.reoffered + extraOffers,
    tookMs: Date.now() - started,
  });
}

export const GET = (req: NextRequest) => run(req).catch(fail);
export const POST = (req: NextRequest) => run(req).catch(fail);
