import { NextRequest } from 'next/server';
import { getSeatMap } from '@/lib/seats';
import { fail, ok } from '@/lib/http';

export const dynamic = 'force-dynamic';

/** GET /api/shows/:id/seatmap — polled by the client for near-real-time status. */
export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const map = await getSeatMap(params.id);
    const res = ok(map);
    res.headers.set('Cache-Control', 'no-store');
    return res;
  } catch (e) {
    return fail(e);
  }
}
