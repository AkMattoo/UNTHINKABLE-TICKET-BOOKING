import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireUser } from '@/lib/auth';
import { joinWaitlist, waitlistPosition } from '@/lib/waitlist';
import { sendEmail, waitlistJoinedEmail } from '@/lib/email';
import { fail, ok } from '@/lib/http';

const Body = z.object({ categoryId: z.string(), quantity: z.number().int().min(1).max(6).default(1) });

/** POST /api/shows/:id/waitlist — join the FIFO queue for one seat category. */
export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await requireUser(req);
    const { categoryId, quantity } = Body.parse(await req.json());
    const entry = await joinWaitlist({ showId: params.id, categoryId, userId: session.id, quantity });
    const position = await waitlistPosition(entry.id);

    const detail = await prisma.waitlistEntry.findUnique({
      where: { id: entry.id },
      include: { category: true, show: { include: { event: true } } },
    });
    if (detail) {
      try {
        await sendEmail({
          to: session.email,
          subject: `You're #${position} on the waitlist for ${detail.show.event.title}`,
          html: waitlistJoinedEmail({
            name: session.name,
            eventTitle: detail.show.event.title,
            categoryName: detail.category.name,
            position: position ?? entry.position,
          }),
        });
      } catch (e) {
        console.error('[waitlist] join email failed', e);
      }
    }
    return ok({ entry: { id: entry.id, status: entry.status }, position }, 201);
  } catch (e) {
    return fail(e);
  }
}

/** GET /api/shows/:id/waitlist — per-category queue depth + the caller's own place. */
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await requireUser(req);
    const entries = await prisma.waitlistEntry.findMany({
      where: { showId: params.id, status: { in: ['WAITING', 'OFFERED'] } },
      include: { category: true },
      orderBy: { position: 'asc' },
    });
    const byCategory = new Map<string, { categoryId: string; name: string; queueLength: number }>();
    for (const e of entries) {
      const cur = byCategory.get(e.categoryId) ?? { categoryId: e.categoryId, name: e.category.name, queueLength: 0 };
      cur.queueLength++;
      byCategory.set(e.categoryId, cur);
    }
    const mine = entries.filter((e) => e.userId === session.id);
    return ok({
      categories: [...byCategory.values()],
      mine: await Promise.all(
        mine.map(async (m) => ({
          id: m.id, categoryId: m.categoryId, categoryName: m.category.name,
          status: m.status, position: await waitlistPosition(m.id),
        })),
      ),
    });
  } catch (e) {
    return fail(e);
  }
}
