import { NextRequest } from 'next/server';
import { z } from 'zod';
import { requireUser } from '@/lib/auth';
import { holdSeats } from '@/lib/seats';
import { env } from '@/lib/env';
import { fail, ok } from '@/lib/http';

const Body = z.object({ seatIds: z.array(z.string()).min(1).max(10) });

/** POST /api/shows/:id/hold — atomically locks the seats for SEAT_HOLD_TTL_SECONDS. */
export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await requireUser(req);
    const { seatIds } = Body.parse(await req.json());
    const hold = await holdSeats({ showId: params.id, seatIds });
    return ok({ ...hold, ttlSeconds: env.holdTtlSeconds }, 201);
  } catch (e) {
    return fail(e);
  }
}
