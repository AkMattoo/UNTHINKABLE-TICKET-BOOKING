import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { HttpError, requireUser } from '@/lib/auth';
import { fail, ok } from '@/lib/http';

/** GET /api/shows?eventId=... */
export async function GET(req: NextRequest) {
  try {
    const eventId = req.nextUrl.searchParams.get('eventId') ?? undefined;
    const shows = await prisma.show.findMany({
      where: { eventId, startsAt: { gte: new Date() } },
      orderBy: { startsAt: 'asc' },
      include: { venue: true, event: true, prices: true },
    });
    return ok({ shows });
  } catch (e) {
    return fail(e);
  }
}

const CreateShow = z.object({
  eventId: z.string(),
  venueId: z.string(),
  startsAt: z.string().datetime(),
  screen: z.string().default('Screen 1'),
  prices: z.array(z.object({ categoryId: z.string(), priceCents: z.number().int().min(0) })).min(1),
});

/**
 * POST /api/shows — creates the show, its price table, and one ShowSeat row per
 * physical seat in the venue. Materialising the seat map up front is what makes
 * the per-seat conditional UPDATE possible later.
 */
export async function POST(req: NextRequest) {
  try {
    const session = await requireUser(req, ['ORGANISER', 'ADMIN']);
    const body = CreateShow.parse(await req.json());

    const event = await prisma.event.findUnique({ where: { id: body.eventId } });
    if (!event) throw new HttpError(404, 'Event not found');
    if (event.organiserId !== session.id && session.role !== 'ADMIN')
      throw new HttpError(403, 'You can only schedule shows for your own events');

    const seats = await prisma.seat.findMany({ where: { venueId: body.venueId }, select: { id: true } });
    if (seats.length === 0) throw new HttpError(400, 'That venue has no seat layout yet');

    const show = await prisma.$transaction(async (tx) => {
      const created = await tx.show.create({
        data: { eventId: body.eventId, venueId: body.venueId, startsAt: new Date(body.startsAt), screen: body.screen },
      });
      await tx.showPrice.createMany({ data: body.prices.map((p) => ({ ...p, showId: created.id })) });
      await tx.showSeat.createMany({ data: seats.map((s) => ({ showId: created.id, seatId: s.id })) });
      return created;
    });

    return ok({ show, seatsCreated: seats.length }, 201);
  } catch (e) {
    return fail(e);
  }
}
