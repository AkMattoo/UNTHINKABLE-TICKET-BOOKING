import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireUser } from '@/lib/auth';
import { releaseHold } from '@/lib/seats';
import { fail, ok } from '@/lib/http';

/** GET — how much time is left on a hold (drives the checkout countdown). */
export async function GET(_req: NextRequest, { params }: { params: { holdId: string } }) {
  try {
    const seats = await prisma.showSeat.findMany({
      where: { holdId: params.holdId },
      include: { seat: true, show: { include: { event: true, venue: true, prices: true } } },
    });
    if (seats.length === 0) return ok({ active: false, secondsLeft: 0, seats: [] });

    const expiresAt = seats[0].holdExpiresAt!;
    const secondsLeft = Math.max(0, Math.floor((expiresAt.getTime() - Date.now()) / 1000));
    const priceOf = new Map(seats[0].show.prices.map((p) => [p.categoryId, p.priceCents]));

    return ok({
      active: secondsLeft > 0,
      expiresAt,
      secondsLeft,
      show: {
        id: seats[0].showId,
        title: seats[0].show.event.title,
        posterUrl: seats[0].show.event.posterUrl,
        startsAt: seats[0].show.startsAt,
        screen: seats[0].show.screen,
        venue: `${seats[0].show.venue.name}, ${seats[0].show.venue.city}`,
      },
      seats: seats.map((s) => ({
        seatId: s.seatId,
        label: `${s.seat.rowLabel}${s.seat.seatNumber}`,
        priceCents: priceOf.get(s.seat.categoryId) ?? 0,
      })),
      totalCents: seats.reduce((t, s) => t + (priceOf.get(s.seat.categoryId) ?? 0), 0),
      isWaitlistOffer: seats[0].state === 'OFFERED',
    });
  } catch (e) {
    return fail(e);
  }
}

/** DELETE — user abandons checkout explicitly; seats go back on sale at once. */
export async function DELETE(req: NextRequest, { params }: { params: { holdId: string } }) {
  try {
    await requireUser(req);
    const released = await releaseHold(params.holdId);
    return ok({ released });
  } catch (e) {
    return fail(e);
  }
}
