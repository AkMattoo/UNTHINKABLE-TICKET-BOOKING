import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireUser } from '@/lib/auth';
import { expandLayout } from '@/lib/layout';
import { fail, ok } from '@/lib/http';

export async function GET() {
  try {
    const venues = await prisma.venue.findMany({
      orderBy: { name: 'asc' },
      include: { categories: { orderBy: { rank: 'asc' } }, _count: { select: { seats: true, shows: true } } },
    });
    return ok({ venues });
  } catch (e) {
    return fail(e);
  }
}

const CreateVenue = z.object({
  name: z.string().min(2),
  city: z.string().min(2),
  address: z.string().min(5),
  categories: z.array(z.object({ name: z.string(), colour: z.string().default('#4f7cff'), rank: z.number().int().default(0) })).min(1),
  rows: z
    .array(
      z.object({
        rowLabel: z.string().min(1).max(2),
        seats: z.number().int().min(1).max(40),
        category: z.string(),
        aisleAfter: z.array(z.number().int()).optional(),
      }),
    )
    .min(1),
});

/** POST /api/venues — admin defines a venue with its seat layout and categories. */
export async function POST(req: NextRequest) {
  try {
    await requireUser(req, ['ADMIN']);
    const body = CreateVenue.parse(await req.json());

    const venue = await prisma.venue.create({
      data: { name: body.name, city: body.city, address: body.address, categories: { create: body.categories } },
      include: { categories: true },
    });
    const catId = new Map(venue.categories.map((c) => [c.name, c.id]));
    const seats = expandLayout({ ...body, categories: body.categories } as never).map((s) => ({
      venueId: venue.id,
      categoryId: catId.get(s.category)!,
      rowLabel: s.rowLabel,
      seatNumber: s.seatNumber,
      gridRow: s.gridRow,
      gridCol: s.gridCol,
    }));
    await prisma.seat.createMany({ data: seats });

    return ok({ venue, seatsCreated: seats.length }, 201);
  } catch (e) {
    return fail(e);
  }
}
