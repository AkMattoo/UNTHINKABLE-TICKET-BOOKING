import { NextRequest } from 'next/server';
import { getSession } from '@/lib/auth';
import { ok } from '@/lib/http';

export async function GET(req: NextRequest) {
  const session = await getSession(req);
  return ok({ user: session });
}
