import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { hashPassword, signSession, SESSION_COOKIE, HttpError } from '@/lib/auth';
import { fail, ok } from '@/lib/http';

const Body = z.object({
  name: z.string().min(2).max(80),
  email: z.string().email(),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  phone: z.string().max(20).optional(),
  role: z.enum(['CUSTOMER', 'ORGANISER']).default('CUSTOMER'),
});

export async function POST(req: NextRequest) {
  try {
    const body = Body.parse(await req.json());
    const existing = await prisma.user.findUnique({ where: { email: body.email.toLowerCase() } });
    if (existing) throw new HttpError(409, 'An account with that email already exists');

    const user = await prisma.user.create({
      data: {
        name: body.name,
        email: body.email.toLowerCase(),
        phone: body.phone,
        role: body.role,
        passwordHash: await hashPassword(body.password),
      },
    });

    const token = await signSession({ id: user.id, email: user.email, name: user.name, role: user.role });
    const res = ok({ user: { id: user.id, name: user.name, email: user.email, role: user.role }, token }, 201);
    res.cookies.set(SESSION_COOKIE, token, {
      httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/', maxAge: 60 * 60 * 24 * 7,
    });
    return res;
  } catch (e) {
    return fail(e);
  }
}
