import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { verifyPassword, signSession, SESSION_COOKIE, HttpError } from '@/lib/auth';
import { fail, ok } from '@/lib/http';

const Body = z.object({ email: z.string().email(), password: z.string().min(1) });

export async function POST(req: NextRequest) {
  try {
    const { email, password } = Body.parse(await req.json());
    const user = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
    if (!user || !(await verifyPassword(password, user.passwordHash)))
      throw new HttpError(401, 'Invalid email or password');

    const token = await signSession({ id: user.id, email: user.email, name: user.name, role: user.role });
    const res = ok({ user: { id: user.id, name: user.name, email: user.email, role: user.role }, token });
    res.cookies.set(SESSION_COOKIE, token, {
      httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/', maxAge: 60 * 60 * 24 * 7,
    });
    return res;
  } catch (e) {
    return fail(e);
  }
}
