import { NextRequest } from 'next/server';
import { loadOffer, seatLabel } from '@/lib/waitlist';
import { fail, ok } from '@/lib/http';

export const dynamic = 'force-dynamic';

/** GET /api/offers/:token — inspect a time-limited waitlist offer. */
export async function GET(_req: NextRequest, { params }: { params: { token: string } }) {
  try {
    const { entry, showSeat, priceCents } = await loadOffer(params.token);
    return ok({
      offer: {
        token: params.token,
        showId: entry.showId,
        expiresAt: entry.offerExpiresAt,
        secondsLeft: Math.max(0, Math.floor((entry.offerExpiresAt!.getTime() - Date.now()) / 1000)),
        seat: seatLabel(showSeat.seat.rowLabel, showSeat.seat.seatNumber),
        seatId: showSeat.seatId,
        categoryName: entry.category.name,
        priceCents,
        customer: { name: entry.user.name, email: entry.user.email },
        show: {
          title: entry.show.event.title,
          posterUrl: entry.show.event.posterUrl,
          startsAt: entry.show.startsAt,
          screen: entry.show.screen,
          venue: `${entry.show.venue.name}, ${entry.show.venue.city}`,
        },
      },
    });
  } catch (e) {
    return fail(e);
  }
}
