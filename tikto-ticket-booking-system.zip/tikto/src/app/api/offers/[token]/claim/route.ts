import { NextRequest } from 'next/server';
import { z } from 'zod';
import { HttpError, requireUser } from '@/lib/auth';
import { loadOffer } from '@/lib/waitlist';
import { confirmBooking } from '@/lib/bookings';
import { fail, ok } from '@/lib/http';

const Body = z.object({
  contactName: z.string().min(2).optional(),
  contactEmail: z.string().email().optional(),
  contactPhone: z.string().max(20).optional(),
});

/**
 * POST /api/offers/:token/claim
 * The offer token doubles as the hold id, so claiming is the ordinary
 * booking commit — same atomicity guarantees, no second code path.
 */
export async function POST(req: NextRequest, { params }: { params: { token: string } }) {
  try {
    const session = await requireUser(req);
    const body = Body.parse(await req.json().catch(() => ({})));
    const { entry } = await loadOffer(params.token);
    if (entry.userId !== session.id) throw new HttpError(403, 'This offer belongs to another customer');

    const result = await confirmBooking({
      userId: session.id,
      showId: entry.showId,
      holdId: params.token,
      contactName: body.contactName ?? entry.user.name,
      contactEmail: body.contactEmail ?? entry.user.email,
      contactPhone: body.contactPhone,
    });

    return ok(
      {
        booking: {
          id: result.booking.id, reference: result.booking.reference,
          seats: result.seats, totalCents: result.totalCents, qrDataUrl: result.qrDataUrl,
        },
        source: 'WAITLIST_OFFER',
      },
      201,
    );
  } catch (e) {
    return fail(e);
  }
}
