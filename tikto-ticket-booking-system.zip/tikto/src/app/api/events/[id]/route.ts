import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { HttpError } from '@/lib/auth';
import { fail, ok } from '@/lib/http';

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const event = await prisma.event.findUnique({
      where: { id: params.id },
      include: {
        organiser: { select: { id: true, name: true } },
        shows: {
          where: { startsAt: { gte: new Date() } },
          orderBy: { startsAt: 'asc' },
          include: {
            venue: { include: { categories: { orderBy: { rank: 'asc' } } } },
            prices: true,
            _count: { select: { showSeats: true } },
          },
        },
      },
    });
    if (!event) throw new HttpError(404, 'Event not found');

    const availability = await prisma.showSeat.groupBy({
      by: ['showId'],
      where: { showId: { in: event.shows.map((s) => s.id) }, state: 'AVAILABLE' },
      _count: { _all: true },
    });
    const availableBy = new Map(availability.map((a) => [a.showId, a._count._all]));

    return ok({
      event: {
        ...event,
        shows: event.shows.map((s) => ({
          id: s.id, startsAt: s.startsAt, screen: s.screen, venue: s.venue, prices: s.prices,
          totalSeats: s._count.showSeats,
          availableSeats: availableBy.get(s.id) ?? 0,
          soldOut: (availableBy.get(s.id) ?? 0) === 0,
        })),
      },
    });
  } catch (e) {
    return fail(e);
  }
}
