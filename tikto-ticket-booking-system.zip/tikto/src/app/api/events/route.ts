import { NextRequest } from 'next/server';
import { z } from 'zod';
import { Prisma } from '@prisma/client';
import { prisma } from '@/lib/prisma';
import { requireUser } from '@/lib/auth';
import { fail, ok } from '@/lib/http';

/** GET /api/events?q=&type=MOVIE&city=Mumbai&date=2026-08-26&language=Hindi */
export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const q = sp.get('q')?.trim();
    const type = sp.get('type');
    const city = sp.get('city');
    const language = sp.get('language');
    const date = sp.get('date');

    const showFilter: Prisma.ShowWhereInput = { startsAt: { gte: new Date() } };
    if (city) showFilter.venue = { city: { equals: city, mode: 'insensitive' } };
    if (date) {
      const from = new Date(`${date}T00:00:00`);
      const to = new Date(from.getTime() + 86_400_000);
      showFilter.startsAt = { gte: new Date(Math.max(from.getTime(), Date.now())), lt: to };
    }

    const where: Prisma.EventWhereInput = { shows: { some: showFilter } };
    if (q) where.OR = [{ title: { contains: q, mode: 'insensitive' } }, { genre: { contains: q, mode: 'insensitive' } }];
    if (type === 'MOVIE' || type === 'CONCERT') where.type = type;
    if (language) where.language = { equals: language, mode: 'insensitive' };

    const events = await prisma.event.findMany({
      where,
      include: {
        shows: {
          where: showFilter,
          orderBy: { startsAt: 'asc' },
          take: 8,
          include: { venue: { select: { id: true, name: true, city: true } } },
        },
      },
      orderBy: { createdAt: 'asc' },
    });

    return ok({
      count: events.length,
      events: events.map((e) => ({
        id: e.id, type: e.type, title: e.title, description: e.description, posterUrl: e.posterUrl,
        language: e.language, genre: e.genre, durationMin: e.durationMin, certificate: e.certificate,
        cities: [...new Set(e.shows.map((s) => s.venue.city))],
        nextShow: e.shows[0] ?? null,
        showCount: e.shows.length,
      })),
    });
  } catch (e) {
    return fail(e);
  }
}

const CreateEvent = z.object({
  type: z.enum(['MOVIE', 'CONCERT']),
  title: z.string().min(2),
  description: z.string().min(10),
  posterUrl: z.string().url().nullable().optional(),
  language: z.string().default('English'),
  genre: z.string().default(''),
  durationMin: z.number().int().min(20).max(400).default(120),
  certificate: z.string().default('UA'),
});

/** POST /api/events — organiser/admin only. */
export async function POST(req: NextRequest) {
  try {
    const session = await requireUser(req, ['ORGANISER', 'ADMIN']);
    const body = CreateEvent.parse(await req.json());
    const event = await prisma.event.create({ data: { ...body, organiserId: session.id } });
    return ok({ event }, 201);
  } catch (e) {
    return fail(e);
  }
}
