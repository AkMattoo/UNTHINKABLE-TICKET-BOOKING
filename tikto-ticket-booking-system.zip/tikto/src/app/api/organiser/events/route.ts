import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireUser } from '@/lib/auth';
import { fail, ok } from '@/lib/http';

/** GET /api/organiser/events — the organiser's catalogue with per-show revenue. */
export async function GET(req: NextRequest) {
  try {
    const session = await requireUser(req, ['ORGANISER', 'ADMIN']);
    const events = await prisma.event.findMany({
      where: session.role === 'ADMIN' ? {} : { organiserId: session.id },
      include: {
        shows: {
          include: { venue: true, _count: { select: { showSeats: true } } },
          orderBy: { startsAt: 'asc' },
        },
      },
      orderBy: { createdAt: 'asc' },
    });

    const showIds = events.flatMap((e) => e.shows.map((s) => s.id));
    const revenue = await prisma.booking.groupBy({
      by: ['showId', 'status'],
      where: { showId: { in: showIds } },
      _sum: { totalCents: true },
      _count: { _all: true },
    });
    const sold = await prisma.showSeat.groupBy({
      by: ['showId'],
      where: { showId: { in: showIds }, state: 'BOOKED' },
      _count: { _all: true },
    });
    const soldBy = new Map(sold.map((s) => [s.showId, s._count._all]));

    return ok({
      events: events.map((e) => {
        const shows = e.shows.map((s) => {
          const conf = revenue.find((r) => r.showId === s.id && r.status === 'CONFIRMED');
          return {
            id: s.id, startsAt: s.startsAt, screen: s.screen, venue: s.venue.name, city: s.venue.city,
            capacity: s._count.showSeats,
            seatsSold: soldBy.get(s.id) ?? 0,
            bookings: conf?._count._all ?? 0,
            revenueCents: conf?._sum.totalCents ?? 0,
          };
        });
        return {
          id: e.id, title: e.title, type: e.type, posterUrl: e.posterUrl,
          shows,
          totalRevenueCents: shows.reduce((t, s) => t + s.revenueCents, 0),
          totalSeatsSold: shows.reduce((t, s) => t + s.seatsSold, 0),
        };
      }),
    });
  } catch (e) {
    return fail(e);
  }
}
