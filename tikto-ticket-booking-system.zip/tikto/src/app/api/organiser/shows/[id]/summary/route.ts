import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { HttpError, requireUser } from '@/lib/auth';
import { fail, ok } from '@/lib/http';

/** GET /api/organiser/shows/:id/summary — occupancy, revenue and waitlist depth. */
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await requireUser(req, ['ORGANISER', 'ADMIN']);
    const show = await prisma.show.findUnique({
      where: { id: params.id },
      include: { event: true, venue: { include: { categories: true } }, prices: true },
    });
    if (!show) throw new HttpError(404, 'Show not found');
    if (show.event.organiserId !== session.id && session.role !== 'ADMIN')
      throw new HttpError(403, 'Not your event');

    const seats = await prisma.showSeat.findMany({ where: { showId: params.id }, include: { seat: true } });
    const bookings = await prisma.booking.findMany({ where: { showId: params.id } });
    const waitlist = await prisma.waitlistEntry.groupBy({
      by: ['categoryId', 'status'],
      where: { showId: params.id },
      _count: { _all: true },
    });

    const priceOf = new Map(show.prices.map((p) => [p.categoryId, p.priceCents]));
    const confirmed = bookings.filter((b) => b.status === 'CONFIRMED');
    const cancelled = bookings.filter((b) => b.status === 'CANCELLED');

    const byCategory = show.venue.categories.map((c) => {
      const mine = seats.filter((s) => s.seat.categoryId === c.id);
      const sold = mine.filter((s) => s.state === 'BOOKED').length;
      return {
        category: c.name,
        priceCents: priceOf.get(c.id) ?? 0,
        total: mine.length,
        sold,
        held: mine.filter((s) => s.state === 'HELD').length,
        offered: mine.filter((s) => s.state === 'OFFERED').length,
        available: mine.filter((s) => s.state === 'AVAILABLE').length,
        revenueCents: sold * (priceOf.get(c.id) ?? 0),
        waitlistWaiting: waitlist.find((w) => w.categoryId === c.id && w.status === 'WAITING')?._count._all ?? 0,
        waitlistOffered: waitlist.find((w) => w.categoryId === c.id && w.status === 'OFFERED')?._count._all ?? 0,
        waitlistConverted: waitlist.find((w) => w.categoryId === c.id && w.status === 'CONVERTED')?._count._all ?? 0,
      };
    });

    const seatsSold = byCategory.reduce((t, c) => t + c.sold, 0);
    return ok({
      show: { id: show.id, title: show.event.title, startsAt: show.startsAt, screen: show.screen, venue: show.venue.name },
      totals: {
        capacity: seats.length,
        seatsSold,
        occupancyPct: seats.length ? Math.round((seatsSold / seats.length) * 1000) / 10 : 0,
        grossRevenueCents: confirmed.reduce((t, b) => t + b.totalCents, 0),
        refundedCents: cancelled.reduce((t, b) => t + b.totalCents, 0),
        bookings: confirmed.length,
        cancellations: cancelled.length,
        waitlistDepth: waitlist.filter((w) => w.status === 'WAITING').reduce((t, w) => t + w._count._all, 0),
        waitlistConversions: waitlist.filter((w) => w.status === 'CONVERTED').reduce((t, w) => t + w._count._all, 0),
      },
      byCategory,
    });
  } catch (e) {
    return fail(e);
  }
}
