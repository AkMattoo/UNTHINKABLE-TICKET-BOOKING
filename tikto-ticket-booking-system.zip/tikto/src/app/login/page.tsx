'use client';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Suspense, useState } from 'react';
import { Spinner } from '@/components/ui';

const DEMO = [
  ['customer@tikto.dev', 'Customer'],
  ['organiser@tikto.dev', 'Organiser'],
  ['admin@tikto.dev', 'Admin'],
];

function LoginForm() {
  const router = useRouter();
  const next = useSearchParams().get('next') ?? '/';
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError('');
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) return setError(data.error ?? 'Sign in failed');
    router.push(next);
    router.refresh();
  }

  return (
    <div className="mx-auto max-w-sm space-y-5 pt-8">
      <div>
        <h1 className="text-2xl font-bold">Welcome back</h1>
        <p className="mt-1 text-sm text-muted">Sign in to book seats and manage your tickets.</p>
      </div>
      <form onSubmit={submit} className="card space-y-3 p-5">
        <div>
          <label className="label">Email</label>
          <input className="input" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
          <label className="label">Password</label>
          <input className="input" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        {error && <p className="text-sm text-red-400">{error}</p>}
        <button className="btn-primary w-full" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
        <p className="text-center text-xs text-muted">
          No account? <Link href="/register" className="text-accent">Create one</Link>
        </p>
      </form>

      <div className="card p-4">
        <p className="text-xs font-semibold text-muted">Demo accounts — password <code className="text-accent">Password123!</code></p>
        <div className="mt-2 flex flex-wrap gap-2">
          {DEMO.map(([mail, label]) => (
            <button
              key={mail}
              type="button"
              onClick={() => {
                setEmail(mail);
                setPassword('Password123!');
              }}
              className="btn-ghost !py-1 !px-2.5 text-xs"
            >
              {label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<Spinner />}>
      <LoginForm />
    </Suspense>
  );
}
