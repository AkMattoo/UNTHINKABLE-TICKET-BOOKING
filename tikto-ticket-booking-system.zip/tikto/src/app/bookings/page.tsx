'use client';
import Link from 'next/link';
import { Suspense, useCallback, useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { Empty, ErrorBox, Spinner, inr, when } from '@/components/ui';

type Booking = {
  id: string; reference: string; status: string; totalCents: number; seatCount: number;
  qrDataUrl: string | null; seats: string[]; cancellable: boolean;
  show: { id: string; title: string; posterUrl: string | null; startsAt: string; screen: string; venue: string };
};

function BookingsInner() {
  const sp = useSearchParams();
  const highlight = sp.get('highlight');
  const [bookings, setBookings] = useState<Booking[] | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState('');
  const [flash, setFlash] = useState('');

  const load = useCallback(() => {
    fetch('/api/bookings')
      .then((r) => r.json())
      .then((d) => (d.error ? setError(d.error) : setBookings(d.bookings)))
      .catch(() => setError('Could not load your bookings'));
  }, []);

  useEffect(load, [load]);

  async function cancel(id: string) {
    if (!confirm('Cancel this booking? The seats go back on sale and are offered to the waitlist immediately.')) return;
    setBusy(id);
    const res = await fetch(`/api/bookings/${id}/cancel`, { method: 'POST' });
    const data = await res.json();
    setBusy('');
    if (!res.ok) return setError(data.error);
    setFlash(
      `Cancelled ${data.reference}. ${data.seatsReleased} seat(s) released` +
        (data.offersSent > 0 ? `, ${data.offersSent} waitlist offer(s) emailed straight away.` : '.'),
    );
    load();
  }

  if (error && !bookings) return <ErrorBox message={`${error} — you may need to sign in.`} />;
  if (!bookings) return <Spinner />;
  if (bookings.length === 0)
    return <Empty title="No bookings yet" hint="Your tickets and QR codes will show up here." href="/" cta="Browse events" />;

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold">My bookings</h1>
      {flash && <div className="card border-accent/40 bg-accent/5 p-3 text-sm text-accent">{flash}</div>}
      {bookings.map((b) => (
        <div
          key={b.id}
          className={`card p-4 ${b.reference === highlight ? 'border-accent' : ''} ${b.status === 'CANCELLED' ? 'opacity-60' : ''}`}
        >
          <div className="flex flex-col gap-4 sm:flex-row">
            {b.qrDataUrl && b.status === 'CONFIRMED' ? (
              <img src={b.qrDataUrl} alt={`QR ticket ${b.reference}`} className="h-32 w-32 shrink-0 rounded-lg bg-white p-1.5" />
            ) : (
              <div className="flex h-32 w-32 shrink-0 items-center justify-center rounded-lg border border-line text-xs text-muted">
                {b.status}
              </div>
            )}
            <div className="flex-1">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <Link href={`/events`} className="text-lg font-bold hover:text-accent">{b.show.title}</Link>
                  <p className="text-sm text-muted">{b.show.venue} · {b.show.screen}</p>
                  <p className="text-sm text-muted">{when(b.show.startsAt)}</p>
                </div>
                <span
                  className={`chip ${b.status === 'CONFIRMED' ? 'border-emerald-500/40 text-emerald-300' : 'border-red-500/40 text-red-300'}`}
                >
                  {b.status}
                </span>
              </div>
              <div className="mt-3 flex flex-wrap items-center gap-x-6 gap-y-1 text-sm">
                <span className="text-muted">Ref <span className="font-mono text-slate-200">{b.reference}</span></span>
                <span className="text-muted">
                  Seats <span className="text-slate-200">{b.seats.length ? b.seats.join(', ') : `${b.seatCount} (released)`}</span>
                </span>
                <span className="text-muted">Paid <span className="font-semibold text-accent">{inr(b.totalCents)}</span></span>
              </div>
              <div className="mt-4 flex gap-2">
                <Link href={`/verify/${b.reference}`} className="btn-ghost !py-1.5 !px-3 text-xs">Verify ticket</Link>
                {b.cancellable && (
                  <button onClick={() => cancel(b.id)} disabled={busy === b.id} className="btn-danger !py-1.5 !px-3 text-xs">
                    {busy === b.id ? 'Cancelling…' : 'Cancel booking'}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default function BookingsPage() {
  return (
    <Suspense fallback={<Spinner />}>
      <BookingsInner />
    </Suspense>
  );
}
