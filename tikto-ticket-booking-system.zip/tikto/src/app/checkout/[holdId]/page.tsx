'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import { Countdown, ErrorBox, Poster, Spinner, inr, when } from '@/components/ui';

type Hold = {
  active: boolean; expiresAt: string; secondsLeft: number;
  show: { id: string; title: string; posterUrl: string | null; startsAt: string; screen: string; venue: string };
  seats: { seatId: string; label: string; priceCents: number }[];
  totalCents: number; isWaitlistOffer: boolean;
};

export default function CheckoutPage({ params }: { params: { holdId: string } }) {
  const router = useRouter();
  const [hold, setHold] = useState<Hold | null>(null);
  const [left, setLeft] = useState(0);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ contactName: '', contactEmail: '', contactPhone: '' });

  const load = useCallback(async () => {
    const d = await fetch(`/api/holds/${params.holdId}`, { cache: 'no-store' }).then((r) => r.json());
    if (d.error) return setError(d.error);
    setHold(d);
    setLeft(d.secondsLeft);
  }, [params.holdId]);

  useEffect(() => {
    load();
    fetch('/api/auth/me')
      .then((r) => r.json())
      .then((d) => d.user && setForm((f) => ({ ...f, contactName: d.user.name, contactEmail: d.user.email })));
  }, [load]);

  // Local countdown, re-synced against the server every 15s so a clock skew
  // can never let someone submit against a hold the DB has already released.
  useEffect(() => {
    const tick = setInterval(() => setLeft((s) => Math.max(0, s - 1)), 1000);
    const sync = setInterval(load, 15000);
    return () => {
      clearInterval(tick);
      clearInterval(sync);
    };
  }, [load]);

  async function release() {
    await fetch(`/api/holds/${params.holdId}`, { method: 'DELETE' });
    router.push(hold ? `/shows/${hold.show.id}` : '/');
  }

  async function pay() {
    if (!hold) return;
    setBusy(true);
    setError('');
    const res = await fetch('/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ showId: hold.show.id, holdId: params.holdId, ...form }),
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) return setError(data.error ?? 'Booking failed');
    router.push(`/bookings?highlight=${data.booking.reference}`);
  }

  if (error && !hold) return <ErrorBox message={error} />;
  if (!hold) return <Spinner />;

  const expired = left <= 0 || !hold.active;

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <div className={`card flex items-center justify-between p-4 ${expired ? 'border-red-500/50' : 'border-accent/40'}`}>
        <div>
          <p className="text-sm font-semibold">{expired ? 'Your hold has expired' : 'Seats held for you'}</p>
          <p className="text-xs text-muted">
            {expired
              ? 'These seats went back on sale. Pick again from the seat map.'
              : `Complete payment before the timer runs out${hold.isWaitlistOffer ? ' — this is your waitlist offer' : ''}.`}
          </p>
        </div>
        {expired ? (
          <Link href={`/shows/${hold.show.id}`} className="btn-primary">Back to seat map</Link>
        ) : (
          <Countdown secondsLeft={left} />
        )}
      </div>

      <div className="card flex gap-4 overflow-hidden p-4">
        <Poster url={hold.show.posterUrl} title={hold.show.title} className="h-32 w-24 shrink-0 rounded-lg" />
        <div className="flex-1">
          <h1 className="text-lg font-bold">{hold.show.title}</h1>
          <p className="text-sm text-muted">{hold.show.venue} · {hold.show.screen}</p>
          <p className="text-sm text-muted">{when(hold.show.startsAt)}</p>
          <p className="mt-3 text-sm">
            Seats <span className="font-semibold text-accent">{hold.seats.map((s) => s.label).sort().join(', ')}</span>
          </p>
        </div>
      </div>

      <div className="card p-5">
        <h2 className="text-sm font-semibold">Ticket holder details</h2>
        <p className="mt-1 text-xs text-muted">Your QR e-ticket is emailed to this address.</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <div>
            <label className="label">Full name</label>
            <input className="input" value={form.contactName} onChange={(e) => setForm({ ...form, contactName: e.target.value })} />
          </div>
          <div>
            <label className="label">Email</label>
            <input className="input" type="email" value={form.contactEmail} onChange={(e) => setForm({ ...form, contactEmail: e.target.value })} />
          </div>
          <div>
            <label className="label">Phone (optional)</label>
            <input className="input" value={form.contactPhone} onChange={(e) => setForm({ ...form, contactPhone: e.target.value })} />
          </div>
        </div>
      </div>

      <div className="card p-5">
        <h2 className="text-sm font-semibold">Order summary</h2>
        <ul className="mt-3 space-y-1.5 text-sm">
          {hold.seats.map((s) => (
            <li key={s.seatId} className="flex justify-between">
              <span className="text-muted">Seat {s.label}</span>
              <span>{inr(s.priceCents)}</span>
            </li>
          ))}
        </ul>
        <div className="mt-3 flex justify-between border-t border-line pt-3 font-bold">
          <span>Total payable</span>
          <span className="text-accent">{inr(hold.totalCents)}</span>
        </div>
        {error && <p className="mt-3 text-sm text-red-400">{error}</p>}
        <div className="mt-5 flex gap-3">
          <button onClick={pay} disabled={expired || busy || !form.contactEmail} className="btn-primary flex-1">
            {busy ? 'Confirming…' : `Pay ${inr(hold.totalCents)} & get tickets`}
          </button>
          <button onClick={release} className="btn-ghost">Release seats</button>
        </div>
        <p className="mt-3 text-[11px] text-muted">
          Payment is simulated for this build — confirming issues a real booking, QR ticket and email.
        </p>
      </div>
    </div>
  );
}
