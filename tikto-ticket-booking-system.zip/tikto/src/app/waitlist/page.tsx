'use client';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { Empty, ErrorBox, Spinner, when } from '@/components/ui';

type Entry = {
  id: string; status: string; quantity: number; categoryName: string;
  position: number | null; offerExpiresAt: string | null; offerToken: string | null;
  show: { id: string; title: string; startsAt: string; venue: string };
};

export default function WaitlistPage() {
  const [entries, setEntries] = useState<Entry[] | null>(null);
  const [error, setError] = useState('');

  const load = useCallback(() => {
    fetch('/api/waitlist')
      .then((r) => r.json())
      .then((d) => (d.error ? setError(d.error) : setEntries(d.entries)))
      .catch(() => setError('Could not load your waitlist'));
  }, []);

  useEffect(() => {
    load();
    const t = setInterval(load, 10000);
    return () => clearInterval(t);
  }, [load]);

  async function leave(id: string) {
    const res = await fetch(`/api/waitlist/${id}`, { method: 'DELETE' });
    const d = await res.json();
    if (!res.ok) return setError(d.error);
    load();
  }

  if (error && !entries) return <ErrorBox message={`${error} — you may need to sign in.`} />;
  if (!entries) return <Spinner />;
  if (entries.length === 0)
    return <Empty title="You're not on any waitlists" hint="Join one from a sold-out show and we'll email you the moment a seat frees up." href="/" cta="Browse events" />;

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold">My waitlists</h1>
      {entries.map((e) => (
        <div key={e.id} className="card flex flex-wrap items-center justify-between gap-3 p-4">
          <div>
            <p className="font-semibold">{e.show.title}</p>
            <p className="text-sm text-muted">{e.show.venue} · {when(e.show.startsAt)}</p>
            <p className="mt-1 text-xs text-muted">
              {e.categoryName} · {e.quantity} seat{e.quantity > 1 ? 's' : ''}
            </p>
          </div>
          <div className="flex items-center gap-3">
            {e.status === 'WAITING' && (
              <>
                <span className="chip border-accent/40 text-accent">#{e.position} in queue</span>
                <button onClick={() => leave(e.id)} className="btn-ghost !py-1.5 !px-3 text-xs">Leave</button>
              </>
            )}
            {e.status === 'OFFERED' && e.offerToken && (
              <Link href={`/offer/${e.offerToken}`} className="btn-primary !py-1.5 !px-3 text-xs">
                Claim your seat
              </Link>
            )}
            {['CONVERTED', 'EXPIRED', 'CANCELLED'].includes(e.status) && (
              <span className="chip">{e.status.toLowerCase()}</span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
