import { Prisma, SeatState } from '@prisma/client';
import { randomUUID } from 'crypto';
import { prisma } from './prisma';
import { env } from './env';
import { HttpError } from './auth';

/**
 * ============================================================================
 *  SEAT STATE ENGINE
 * ============================================================================
 *  Every transition below is expressed as ONE conditional SQL UPDATE whose
 *  WHERE clause encodes the precondition. Postgres evaluates that predicate
 *  while holding a row lock, so two concurrent requests for the same seat
 *  serialise: the first flips the row, the second re-checks the predicate
 *  after the lock is released, no longer matches, and updates 0 rows.
 *
 *  We then compare `rowsUpdated` with `seatIds.length`. A partial match means
 *  somebody else won at least one seat, so we throw and the surrounding
 *  transaction rolls back — a hold is all-or-nothing.
 *
 *  No application-level mutex, no optimistic-retry loop on the happy path,
 *  and it stays correct across multiple serverless instances because the
 *  arbiter is the database, not the process.
 * ============================================================================
 */

const DEADLOCK = '40P01';
const SERIALIZATION = '40001';

/** Retries only on genuine Postgres concurrency errors, never on business failures. */
export async function withRetry<T>(fn: () => Promise<T>, attempts = 3): Promise<T> {
  let lastErr: unknown;
  for (let i = 0; i < attempts; i++) {
    try {
      return await fn();
    } catch (err) {
      const code = (err as { code?: string })?.code;
      if (code !== DEADLOCK && code !== SERIALIZATION) throw err;
      lastErr = err;
      await new Promise((r) => setTimeout(r, 25 * (i + 1) + Math.random() * 25));
    }
  }
  throw lastErr;
}

export type HoldResult = {
  holdId: string;
  expiresAt: Date;
  seatIds: string[];
  totalCents: number;
};

/**
 * Place an exclusive, time-limited hold on a set of seats for one show.
 * A seat qualifies if it is AVAILABLE, or if it is HELD/OFFERED by a hold
 * that has already expired but which the sweeper has not reclaimed yet
 * (lazy expiry — correctness never depends on the sweeper running on time).
 */
export async function holdSeats(opts: {
  showId: string;
  seatIds: string[];
  ttlSeconds?: number;
  holdId?: string;
}): Promise<HoldResult> {
  const { showId } = opts;
  const seatIds = [...new Set(opts.seatIds)];
  if (seatIds.length === 0) throw new HttpError(400, 'Select at least one seat');
  if (seatIds.length > 10) throw new HttpError(400, 'A maximum of 10 seats can be booked at once');

  const ttl = opts.ttlSeconds ?? env.holdTtlSeconds;
  const holdId = opts.holdId ?? randomUUID();
  const expiresAt = new Date(Date.now() + ttl * 1000);

  return withRetry(() =>
    prisma.$transaction(async (tx) => {
      const show = await tx.show.findUnique({ where: { id: showId }, select: { id: true, startsAt: true } });
      if (!show) throw new HttpError(404, 'Show not found');
      if (show.startsAt.getTime() < Date.now()) throw new HttpError(409, 'This show has already started');

      const rowsUpdated = await tx.$executeRaw`
        UPDATE show_seats
           SET state           = 'HELD',
               "holdId"        = ${holdId},
               "holdExpiresAt" = ${expiresAt},
               version         = version + 1,
               "updatedAt"     = NOW()
         WHERE "showId" = ${showId}
           AND "seatId" IN (${Prisma.join(seatIds)})
           AND (
                 state = 'AVAILABLE'
              OR (state IN ('HELD', 'OFFERED') AND "holdExpiresAt" < NOW())
           )`;

      if (rowsUpdated !== seatIds.length) {
        // Roll back the seats we did win, and tell the caller precisely what went.
        throw new HttpError(409, 'One or more of those seats were just taken. Please pick again.');
      }

      const priced = await tx.showSeat.findMany({
        where: { showId, seatId: { in: seatIds } },
        select: { seat: { select: { categoryId: true } } },
      });
      const prices = await tx.showPrice.findMany({ where: { showId } });
      const priceOf = new Map(prices.map((p) => [p.categoryId, p.priceCents]));
      const totalCents = priced.reduce((sum, s) => sum + (priceOf.get(s.seat.categoryId) ?? 0), 0);

      await tx.auditLog.create({
        data: {
          action: 'SEAT_HOLD',
          subject: `show:${showId}`,
          detail: `hold ${holdId} on ${seatIds.length} seat(s), ttl ${ttl}s`,
        },
      });

      return { holdId, expiresAt, seatIds, totalCents };
    }),
  );
}

/** Voluntary release (user backs out of checkout) or forced release by the sweeper. */
export async function releaseHold(holdId: string): Promise<number> {
  const released = await prisma.$executeRaw`
    UPDATE show_seats
       SET state           = 'AVAILABLE',
           "holdId"        = NULL,
           "holdExpiresAt" = NULL,
           version         = version + 1,
           "updatedAt"     = NOW()
     WHERE "holdId" = ${holdId}
       AND state IN ('HELD', 'OFFERED')`;
  return released;
}

/** Promote a live hold into a confirmed booking. Fails if the hold lapsed. */
export async function commitHold(tx: Prisma.TransactionClient, holdId: string, bookingId: string, showId: string) {
  const rows = await tx.$executeRaw`
    UPDATE show_seats
       SET state           = 'BOOKED',
           "bookingId"     = ${bookingId},
           "holdId"        = NULL,
           "holdExpiresAt" = NULL,
           version         = version + 1,
           "updatedAt"     = NOW()
     WHERE "showId" = ${showId}
       AND "holdId" = ${holdId}
       AND state IN ('HELD', 'OFFERED')
       AND "holdExpiresAt" > NOW()`;
  if (rows === 0) throw new HttpError(410, 'Your seat hold expired. Please select seats again.');
  return rows;
}

/** Reclaim seats whose hold or offer window has elapsed. Idempotent; safe to run often. */
export async function sweepExpiredHolds(): Promise<{ released: number; holdIds: string[] }> {
  const expiring = await prisma.showSeat.findMany({
    where: { state: { in: [SeatState.HELD, SeatState.OFFERED] }, holdExpiresAt: { lt: new Date() } },
    select: { holdId: true },
    take: 500,
  });
  const holdIds = [...new Set(expiring.map((e) => e.holdId).filter(Boolean) as string[])];

  const released = await prisma.$executeRaw`
    UPDATE show_seats
       SET state           = 'AVAILABLE',
           "holdId"        = NULL,
           "holdExpiresAt" = NULL,
           version         = version + 1,
           "updatedAt"     = NOW()
     WHERE state IN ('HELD', 'OFFERED')
       AND "holdExpiresAt" < NOW()`;

  if (released > 0) {
    await prisma.auditLog.create({
      data: { action: 'SWEEP_RELEASE', subject: 'system', detail: `released ${released} expired seat lock(s)` },
    });
  }
  return { released, holdIds };
}

/** Seat map for rendering: never leaks who holds what, only whether it is takeable. */
export async function getSeatMap(showId: string) {
  const show = await prisma.show.findUnique({
    where: { id: showId },
    include: {
      event: true,
      venue: { include: { categories: { orderBy: { rank: 'asc' } } } },
      prices: true,
    },
  });
  if (!show) throw new HttpError(404, 'Show not found');

  const seats = await prisma.showSeat.findMany({
    where: { showId },
    include: { seat: true },
  });

  const priceOf = new Map(show.prices.map((p) => [p.categoryId, p.priceCents]));
  const now = Date.now();

  const cells = seats
    .map((s) => {
      const lockLapsed = s.holdExpiresAt ? s.holdExpiresAt.getTime() < now : true;
      const effective =
        (s.state === 'HELD' || s.state === 'OFFERED') && lockLapsed ? 'AVAILABLE' : s.state;
      return {
        seatId: s.seatId,
        rowLabel: s.seat.rowLabel,
        seatNumber: s.seat.seatNumber,
        gridRow: s.seat.gridRow,
        gridCol: s.seat.gridCol,
        categoryId: s.seat.categoryId,
        priceCents: priceOf.get(s.seat.categoryId) ?? 0,
        state: effective as SeatState,
      };
    })
    .sort((a, b) => a.gridRow - b.gridRow || a.gridCol - b.gridCol);

  const byCategory = show.venue.categories.map((c) => {
    const mine = cells.filter((s) => s.categoryId === c.id);
    return {
      id: c.id,
      name: c.name,
      colour: c.colour,
      priceCents: priceOf.get(c.id) ?? 0,
      total: mine.length,
      available: mine.filter((s) => s.state === 'AVAILABLE').length,
    };
  });

  return {
    show: {
      id: show.id,
      screen: show.screen,
      startsAt: show.startsAt,
      event: show.event,
      venue: { id: show.venue.id, name: show.venue.name, city: show.venue.city },
    },
    categories: byCategory,
    seats: cells,
    soldOut: cells.every((s) => s.state !== 'AVAILABLE'),
    availableCount: cells.filter((s) => s.state === 'AVAILABLE').length,
    generatedAt: new Date().toISOString(),
  };
}
