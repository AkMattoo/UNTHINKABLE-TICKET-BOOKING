export const env = {
  jwtSecret: process.env.JWT_SECRET || 'dev-only-insecure-secret-change-me',
  appUrl: process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000',
  holdTtlSeconds: Number(process.env.SEAT_HOLD_TTL_SECONDS || 600),
  offerTtlSeconds: Number(process.env.WAITLIST_OFFER_TTL_SECONDS || 900),
  resendApiKey: process.env.RESEND_API_KEY || '',
  emailFrom: process.env.EMAIL_FROM || 'Tikto <onboarding@resend.dev>',
  cronSecret: process.env.CRON_SECRET || 'dev-cron-secret',
  tmdbApiKey: process.env.TMDB_API_KEY || '',
};
