import { BookingStatus } from '@prisma/client';
import { prisma } from './prisma';
import { HttpError } from './auth';
import { bookingReference, generateTicketQr } from './qr';
import { commitHold, withRetry } from './seats';
import { markWaitlistConverted, offerFreedSeats, seatLabel } from './waitlist';
import { bookingCancelledEmail, bookingConfirmedEmail, sendEmail } from './email';

/** Turn a live hold (checkout hold OR waitlist offer) into a confirmed booking + QR e-ticket. */
export async function confirmBooking(opts: {
  userId: string;
  showId: string;
  holdId: string;
  contactName: string;
  contactEmail: string;
  contactPhone?: string;
}) {
  const booking = await withRetry(() =>
    prisma.$transaction(async (tx) => {
      const held = await tx.showSeat.findMany({
        where: { showId: opts.showId, holdId: opts.holdId },
        include: { seat: true },
      });
      if (held.length === 0) throw new HttpError(410, 'Your seat hold expired. Please select seats again.');

      const show = await tx.show.findUniqueOrThrow({
        where: { id: opts.showId },
        include: { event: true, venue: true, prices: true },
      });
      const priceOf = new Map(show.prices.map((p) => [p.categoryId, p.priceCents]));
      const totalCents = held.reduce((sum, s) => sum + (priceOf.get(s.seat.categoryId) ?? 0), 0);

      const reference = bookingReference();
      const created = await tx.booking.create({
        data: {
          reference,
          userId: opts.userId,
          showId: opts.showId,
          status: BookingStatus.CONFIRMED,
          totalCents,
          seatCount: held.length,
          contactName: opts.contactName,
          contactEmail: opts.contactEmail,
          contactPhone: opts.contactPhone,
          confirmedAt: new Date(),
        },
      });

      // Fails (and rolls the booking back) if the hold lapsed mid-checkout.
      await commitHold(tx, opts.holdId, created.id, opts.showId);

      const offer = await tx.waitlistEntry.findUnique({ where: { offerToken: opts.holdId } });
      if (offer) await markWaitlistConverted(tx, offer.id);

      await tx.auditLog.create({
        data: {
          actorId: opts.userId,
          action: 'BOOKING_CONFIRMED',
          subject: `booking:${created.id}`,
          detail: `${reference} · ${held.length} seat(s) · ${totalCents} paise${offer ? ' · via waitlist offer' : ''}`,
        },
      });

      return {
        booking: created,
        show,
        seats: held.map((h) => seatLabel(h.seat.rowLabel, h.seat.seatNumber)).sort(),
        totalCents,
      };
    }),
  );

  // QR + email after commit — the ticket exists whether or not mail is up.
  const qrDataUrl = await generateTicketQr(booking.booking.reference);
  await prisma.booking.update({ where: { id: booking.booking.id }, data: { qrDataUrl } });

  try {
    await sendEmail({
      to: opts.contactEmail,
      subject: `🎟️ ${booking.booking.reference} — your tickets for ${booking.show.event.title}`,
      html: bookingConfirmedEmail({
        name: opts.contactName,
        reference: booking.booking.reference,
        eventTitle: booking.show.event.title,
        venue: `${booking.show.venue.name}, ${booking.show.venue.city}`,
        startsAt: booking.show.startsAt,
        seats: booking.seats,
        totalCents: booking.totalCents,
        qrDataUrl,
      }),
      attachQrDataUrl: qrDataUrl,
    });
  } catch (e) {
    console.error('[booking] confirmation email failed', e);
  }

  return { ...booking, qrDataUrl };
}

/** Cancel a booking, free its seats, and immediately hand them to the waitlist. */
export async function cancelBooking(bookingId: string, actor: { id: string; role: string }) {
  const result = await prisma.$transaction(async (tx) => {
    const booking = await tx.booking.findUnique({
      where: { id: bookingId },
      include: { show: { include: { event: true } }, showSeats: { include: { seat: true } }, user: true },
    });
    if (!booking) throw new HttpError(404, 'Booking not found');
    if (booking.userId !== actor.id && actor.role !== 'ADMIN')
      throw new HttpError(403, 'You can only cancel your own bookings');
    if (booking.status !== BookingStatus.CONFIRMED) throw new HttpError(409, 'Booking is not cancellable');
    if (booking.show.startsAt.getTime() < Date.now())
      throw new HttpError(409, 'Cannot cancel after the show has started');

    const seatIds = booking.showSeats.map((s) => s.seatId);

    await tx.$executeRaw`
      UPDATE show_seats
         SET state = 'AVAILABLE', "bookingId" = NULL, "holdId" = NULL, "holdExpiresAt" = NULL,
             version = version + 1, "updatedAt" = NOW()
       WHERE "bookingId" = ${bookingId}`;

    await tx.booking.update({
      where: { id: bookingId },
      data: { status: BookingStatus.CANCELLED, cancelledAt: new Date() },
    });

    await tx.auditLog.create({
      data: {
        actorId: actor.id,
        action: 'BOOKING_CANCELLED',
        subject: `booking:${bookingId}`,
        detail: `${booking.reference} · ${seatIds.length} seat(s) returned to sale`,
      },
    });

    return { booking, seatIds };
  });

  // Auto-assignment runs after the seats are genuinely free.
  const offersSent = await offerFreedSeats(result.booking.showId, result.seatIds);

  try {
    await sendEmail({
      to: result.booking.contactEmail,
      subject: `Cancelled — ${result.booking.reference}`,
      html: bookingCancelledEmail({
        name: result.booking.contactName,
        reference: result.booking.reference,
        eventTitle: result.booking.show.event.title,
        refundCents: result.booking.totalCents,
      }),
    });
  } catch (e) {
    console.error('[booking] cancellation email failed', e);
  }

  return { reference: result.booking.reference, seatsReleased: result.seatIds.length, offersSent };
}
