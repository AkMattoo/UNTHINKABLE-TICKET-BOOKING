import bcrypt from 'bcryptjs';
import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import { NextRequest } from 'next/server';
import { env } from './env';
import { prisma } from './prisma';
import type { Role } from '@prisma/client';

const secret = new TextEncoder().encode(env.jwtSecret);
export const SESSION_COOKIE = 'tikto_session';

export type SessionUser = { id: string; email: string; name: string; role: Role };

export const hashPassword = (plain: string) => bcrypt.hash(plain, 10);
export const verifyPassword = (plain: string, hash: string) => bcrypt.compare(plain, hash);

export async function signSession(user: SessionUser) {
  return new SignJWT({ email: user.email, name: user.name, role: user.role })
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject(user.id)
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(secret);
}

export async function readToken(token: string): Promise<SessionUser | null> {
  try {
    const { payload } = await jwtVerify(token, secret);
    return {
      id: String(payload.sub),
      email: String(payload.email),
      name: String(payload.name),
      role: payload.role as Role,
    };
  } catch {
    return null;
  }
}

/** Session from the httpOnly cookie (server components) or the Authorization header (API clients). */
export async function getSession(req?: NextRequest): Promise<SessionUser | null> {
  let token: string | undefined;
  const bearer = req?.headers.get('authorization');
  if (bearer?.startsWith('Bearer ')) token = bearer.slice(7);
  if (!token) {
    try {
      token = cookies().get(SESSION_COOKIE)?.value;
    } catch {
      /* outside a request scope */
    }
  }
  if (!token) return null;
  return readToken(token);
}

export async function currentUser() {
  const s = await getSession();
  if (!s) return null;
  return prisma.user.findUnique({ where: { id: s.id } });
}

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

/** Throws HttpError unless the caller is authenticated and (optionally) holds one of `roles`. */
export async function requireUser(req?: NextRequest, roles?: Role[]) {
  const session = await getSession(req);
  if (!session) throw new HttpError(401, 'Authentication required');
  if (roles && !roles.includes(session.role)) throw new HttpError(403, 'Insufficient role');
  return session;
}
