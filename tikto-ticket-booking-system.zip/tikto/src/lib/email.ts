import { Resend } from 'resend';
import { env } from './env';
import { money } from './http';

const resend = env.resendApiKey ? new Resend(env.resendApiKey) : null;

type SendArgs = { to: string; subject: string; html: string; attachQrDataUrl?: string };

/**
 * Sends via Resend when RESEND_API_KEY is set; otherwise logs the email so the
 * whole flow stays demonstrable locally with zero third-party signup.
 */
export async function sendEmail({ to, subject, html, attachQrDataUrl }: SendArgs) {
  if (!resend) {
    console.log('\n=== [email:dev] ===\nTo: %s\nSubject: %s\n%s\n===================\n', to, subject, html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 600));
    return { id: 'dev-console', delivered: false as const };
  }
  const attachments = attachQrDataUrl
    ? [{ filename: 'ticket-qr.png', content: attachQrDataUrl.split(',')[1] }]
    : undefined;
  const res = await resend.emails.send({ from: env.emailFrom, to, subject, html, attachments });
  if (res.error) throw new Error(`Email send failed: ${res.error.message}`);
  return { id: res.data?.id ?? 'unknown', delivered: true as const };
}

const shell = (body: string) => `
<div style="font-family:ui-sans-serif,system-ui,Segoe UI,Helvetica,Arial;background:#f4f5f7;padding:24px">
  <div style="max-width:560px;margin:0 auto;background:#fff;border-radius:14px;overflow:hidden;border:1px solid #e4e6eb">
    <div style="background:#0b0d12;color:#f5c518;padding:18px 24px;font-size:20px;font-weight:700;letter-spacing:.5px">TIKTO</div>
    <div style="padding:24px;color:#1b1f2a;font-size:15px;line-height:1.6">${body}</div>
    <div style="padding:16px 24px;border-top:1px solid #eee;color:#8b93a7;font-size:12px">
      Tikto — this is an automated message, please do not reply.
    </div>
  </div>
</div>`;

export function bookingConfirmedEmail(args: {
  name: string;
  reference: string;
  eventTitle: string;
  venue: string;
  startsAt: Date;
  seats: string[];
  totalCents: number;
  qrDataUrl: string;
}) {
  return shell(`
    <h2 style="margin:0 0 6px">Your tickets are confirmed 🎟️</h2>
    <p style="margin:0 0 18px;color:#5a6172">Hi ${args.name}, here is your e-ticket. Show the QR code at the gate.</p>
    <table style="width:100%;border-collapse:collapse;font-size:14px">
      <tr><td style="padding:6px 0;color:#8b93a7">Booking</td><td style="text-align:right;font-weight:700">${args.reference}</td></tr>
      <tr><td style="padding:6px 0;color:#8b93a7">Event</td><td style="text-align:right">${args.eventTitle}</td></tr>
      <tr><td style="padding:6px 0;color:#8b93a7">Venue</td><td style="text-align:right">${args.venue}</td></tr>
      <tr><td style="padding:6px 0;color:#8b93a7">Starts</td><td style="text-align:right">${args.startsAt.toUTCString()}</td></tr>
      <tr><td style="padding:6px 0;color:#8b93a7">Seats</td><td style="text-align:right">${args.seats.join(', ')}</td></tr>
      <tr><td style="padding:6px 0;color:#8b93a7">Paid</td><td style="text-align:right;font-weight:700">${money(args.totalCents)}</td></tr>
    </table>
    <div style="text-align:center;margin:22px 0">
      <img src="${args.qrDataUrl}" alt="Ticket QR" width="220" height="220" style="border:8px solid #fff;border-radius:12px" />
      <div style="color:#8b93a7;font-size:12px;margin-top:6px">${args.reference}</div>
    </div>`);
}

export function waitlistOfferEmail(args: {
  name: string;
  eventTitle: string;
  venue: string;
  startsAt: Date;
  seatLabel: string;
  categoryName: string;
  claimUrl: string;
  expiresAt: Date;
  minutes: number;
}) {
  return shell(`
    <h2 style="margin:0 0 6px">A seat just opened up</h2>
    <p style="margin:0 0 14px;color:#5a6172">
      Hi ${args.name} — you were next on the waitlist for <b>${args.categoryName}</b> at
      <b>${args.eventTitle}</b>, ${args.venue}, ${args.startsAt.toUTCString()}.
    </p>
    <p style="margin:0 0 14px">Seat <b>${args.seatLabel}</b> is held for you for the next
      <b>${args.minutes} minutes</b> (until ${args.expiresAt.toUTCString()}).</p>
    <p style="text-align:center;margin:24px 0">
      <a href="${args.claimUrl}" style="background:#f5c518;color:#0b0d12;padding:13px 26px;border-radius:9px;text-decoration:none;font-weight:700">Claim this seat</a>
    </p>
    <p style="margin:0;color:#8b93a7;font-size:13px">
      If you don't complete the booking in time, the seat automatically passes to the next person in the queue.
    </p>`);
}

export function bookingCancelledEmail(args: { name: string; reference: string; eventTitle: string; refundCents: number }) {
  return shell(`
    <h2 style="margin:0 0 6px">Booking cancelled</h2>
    <p style="margin:0 0 14px;color:#5a6172">Hi ${args.name}, booking <b>${args.reference}</b> for
      <b>${args.eventTitle}</b> has been cancelled and the seats returned to sale.</p>
    <p style="margin:0">Refund due: <b>${money(args.refundCents)}</b> (processed to the original method in 5–7 working days).</p>`);
}

export function waitlistJoinedEmail(args: { name: string; eventTitle: string; categoryName: string; position: number }) {
  return shell(`
    <h2 style="margin:0 0 6px">You're on the waitlist</h2>
    <p style="margin:0;color:#5a6172">Hi ${args.name}, you are <b>#${args.position}</b> in the queue for
      <b>${args.categoryName}</b> seats at <b>${args.eventTitle}</b>. We'll email you the moment a seat frees up.</p>`);
}
