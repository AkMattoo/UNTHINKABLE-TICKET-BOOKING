import { randomUUID } from 'crypto';
import { Prisma, WaitlistStatus } from '@prisma/client';
import { prisma } from './prisma';
import { env } from './env';
import { HttpError } from './auth';
import { sendEmail, waitlistOfferEmail } from './email';
import { withRetry } from './seats';

/**
 * ============================================================================
 *  WAITLIST AUTO-ASSIGNMENT
 * ============================================================================
 *  Queue is FIFO per (show, seat category), ordered by `position`, which is
 *  allocated inside a transaction so two simultaneous joiners cannot share a
 *  slot (a unique index on (showId, categoryId, userId) also blocks doubles).
 *
 *  When seats are freed — a cancellation, or an offer that timed out — we walk
 *  each freed seat and hand it to the head of that category's queue as an
 *  OFFERED seat carrying an unguessable offerToken, with its own TTL. The
 *  OFFERED state reuses the same holdId/holdExpiresAt columns as a normal
 *  checkout hold, so the sweeper, the seat map and commitHold all treat an
 *  offer exactly like a hold. One mechanism, two entry points.
 * ============================================================================
 */

export function seatLabel(rowLabel: string, seatNumber: number) {
  return `${rowLabel}${seatNumber}`;
}

export async function joinWaitlist(opts: {
  showId: string;
  categoryId: string;
  userId: string;
  quantity?: number;
}) {
  const { showId, categoryId, userId } = opts;
  const quantity = opts.quantity ?? 1;

  return prisma.$transaction(async (tx) => {
    const existing = await tx.waitlistEntry.findUnique({
      where: { showId_categoryId_userId: { showId, categoryId, userId } },
    });
    if (existing && ['WAITING', 'OFFERED'].includes(existing.status))
      throw new HttpError(409, 'You are already on this waitlist');

    const last = await tx.waitlistEntry.findFirst({
      where: { showId, categoryId },
      orderBy: { position: 'desc' },
      select: { position: true },
    });
    const position = (last?.position ?? 0) + 1;

    if (existing) {
      return tx.waitlistEntry.update({
        where: { id: existing.id },
        data: { status: WaitlistStatus.WAITING, position, quantity, offerToken: null, offerExpiresAt: null },
      });
    }
    return tx.waitlistEntry.create({
      data: { showId, categoryId, userId, quantity, position, status: WaitlistStatus.WAITING },
    });
  });
}

/** Live queue position among people still WAITING ahead of you. */
export async function waitlistPosition(entryId: string) {
  const entry = await prisma.waitlistEntry.findUnique({ where: { id: entryId } });
  if (!entry) return null;
  const ahead = await prisma.waitlistEntry.count({
    where: {
      showId: entry.showId,
      categoryId: entry.categoryId,
      status: { in: [WaitlistStatus.WAITING, WaitlistStatus.OFFERED] },
      position: { lt: entry.position },
    },
  });
  return ahead + 1;
}

/**
 * Offer each freed seat to the next waiting customer in that seat's category.
 * Returns how many offers actually went out. Safe to call repeatedly.
 */
export async function offerFreedSeats(showId: string, seatIds: string[]): Promise<number> {
  let offers = 0;

  for (const seatId of seatIds) {
    const made = await withRetry(() =>
      prisma.$transaction(async (tx) => {
        const showSeat = await tx.showSeat.findUnique({
          where: { showId_seatId: { showId, seatId } },
          include: { seat: { include: { category: true } }, show: { include: { event: true, venue: true } } },
        });
        if (!showSeat || showSeat.state !== 'AVAILABLE') return null;
        if (showSeat.show.startsAt.getTime() < Date.now()) return null;

        const next = await tx.waitlistEntry.findFirst({
          where: { showId, categoryId: showSeat.seat.categoryId, status: WaitlistStatus.WAITING },
          orderBy: { position: 'asc' },
          include: { user: true },
        });
        if (!next) return null;

        const offerToken = randomUUID();
        const offerExpiresAt = new Date(Date.now() + env.offerTtlSeconds * 1000);

        // Conditional flip: only claims the seat if it is still AVAILABLE.
        const rows = await tx.$executeRaw`
          UPDATE show_seats
             SET state           = 'OFFERED',
                 "holdId"        = ${offerToken},
                 "holdExpiresAt" = ${offerExpiresAt},
                 version         = version + 1,
                 "updatedAt"     = NOW()
           WHERE "showId" = ${showId}
             AND "seatId" = ${seatId}
             AND state = 'AVAILABLE'`;
        if (rows !== 1) return null; // a walk-in customer grabbed it first — fine.

        await tx.waitlistEntry.update({
          where: { id: next.id },
          data: {
            status: WaitlistStatus.OFFERED,
            offerToken,
            offerExpiresAt,
            offeredSeatId: seatId,
            offerCount: { increment: 1 },
          },
        });

        await tx.auditLog.create({
          data: {
            action: 'WAITLIST_OFFER',
            subject: `show:${showId}`,
            detail: `seat ${seatLabel(showSeat.seat.rowLabel, showSeat.seat.seatNumber)} offered to ${next.user.email} (pos ${next.position}), expires ${offerExpiresAt.toISOString()}`,
          },
        });

        return { entry: next, showSeat, offerToken, offerExpiresAt };
      }),
    );

    if (!made) continue;
    offers++;

    // Email outside the transaction: a mail failure must not un-reserve the seat.
    try {
      await sendEmail({
        to: made.entry.user.email,
        subject: `A seat opened up for ${made.showSeat.show.event.title}`,
        html: waitlistOfferEmail({
          name: made.entry.user.name,
          eventTitle: made.showSeat.show.event.title,
          venue: `${made.showSeat.show.venue.name}, ${made.showSeat.show.venue.city}`,
          startsAt: made.showSeat.show.startsAt,
          seatLabel: seatLabel(made.showSeat.seat.rowLabel, made.showSeat.seat.seatNumber),
          categoryName: made.showSeat.seat.category.name,
          claimUrl: `${env.appUrl}/offer/${made.offerToken}`,
          expiresAt: made.offerExpiresAt,
          minutes: Math.round(env.offerTtlSeconds / 60),
        }),
      });
    } catch (e) {
      console.error('[waitlist] offer email failed', e);
    }
  }

  return offers;
}

/**
 * Time-limited offer handling: mark lapsed offers EXPIRED, free their seats,
 * then immediately re-offer those seats to the next person in line.
 */
export async function expireLapsedOffers(): Promise<{ expired: number; reoffered: number }> {
  const lapsed = await prisma.waitlistEntry.findMany({
    where: { status: WaitlistStatus.OFFERED, offerExpiresAt: { lt: new Date() } },
    take: 200,
  });
  if (lapsed.length === 0) return { expired: 0, reoffered: 0 };

  const freedByShow = new Map<string, string[]>();

  for (const entry of lapsed) {
    await prisma.$transaction(async (tx) => {
      await tx.waitlistEntry.update({
        where: { id: entry.id },
        data: { status: WaitlistStatus.EXPIRED, offerToken: null, offerExpiresAt: null, offeredSeatId: null },
      });
      if (entry.offerToken) {
        await tx.$executeRaw`
          UPDATE show_seats
             SET state = 'AVAILABLE', "holdId" = NULL, "holdExpiresAt" = NULL,
                 version = version + 1, "updatedAt" = NOW()
           WHERE "holdId" = ${entry.offerToken} AND state = 'OFFERED'`;
      }
      await tx.auditLog.create({
        data: {
          action: 'WAITLIST_OFFER_EXPIRED',
          subject: `show:${entry.showId}`,
          detail: `entry ${entry.id} did not claim in time; seat returned to the queue`,
        },
      });
    });
    if (entry.offeredSeatId) {
      const arr = freedByShow.get(entry.showId) ?? [];
      arr.push(entry.offeredSeatId);
      freedByShow.set(entry.showId, arr);
    }
  }

  let reoffered = 0;
  for (const [showId, seatIds] of freedByShow) reoffered += await offerFreedSeats(showId, seatIds);
  return { expired: lapsed.length, reoffered };
}

/** Resolve a claim link into a still-valid offer, or explain why it is dead. */
export async function loadOffer(token: string) {
  const entry = await prisma.waitlistEntry.findUnique({
    where: { offerToken: token },
    include: {
      category: true,
      show: { include: { event: true, venue: true, prices: true } },
      user: true,
    },
  });
  if (!entry) throw new HttpError(404, 'This offer link is not valid');
  if (entry.status !== WaitlistStatus.OFFERED) throw new HttpError(410, 'This offer has already been used or expired');
  if (!entry.offerExpiresAt || entry.offerExpiresAt.getTime() < Date.now())
    throw new HttpError(410, 'This offer expired and the seat has moved to the next person in line');

  const showSeat = await prisma.showSeat.findFirst({
    where: { showId: entry.showId, seatId: entry.offeredSeatId ?? '' },
    include: { seat: true },
  });
  if (!showSeat || showSeat.state !== 'OFFERED' || showSeat.holdId !== token)
    throw new HttpError(410, 'The offered seat is no longer reserved for you');

  const price = entry.show.prices.find((p) => p.categoryId === entry.categoryId)?.priceCents ?? 0;

  return { entry, showSeat, priceCents: price };
}

export async function markWaitlistConverted(tx: Prisma.TransactionClient, entryId: string) {
  await tx.waitlistEntry.update({
    where: { id: entryId },
    data: { status: WaitlistStatus.CONVERTED, offerToken: null, offerExpiresAt: null },
  });
}
