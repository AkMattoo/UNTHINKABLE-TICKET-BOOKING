import QRCode from 'qrcode';
import { env } from './env';

/**
 * The QR encodes a verifiable payload rather than a bare string, so a gate
 * scanner can hit /api/verify/<reference> and get a live valid/cancelled answer.
 */
export function ticketPayload(reference: string) {
  return `${env.appUrl}/verify/${reference}`;
}

export async function generateTicketQr(reference: string): Promise<string> {
  return QRCode.toDataURL(ticketPayload(reference), {
    errorCorrectionLevel: 'M',
    margin: 1,
    width: 320,
    color: { dark: '#0b0d12', light: '#ffffff' },
  });
}

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no I/O/0/1
export function bookingReference(): string {
  let s = '';
  for (let i = 0; i < 8; i++) s += ALPHABET[Math.floor(Math.random() * ALPHABET.length)];
  return `TKT-${s.slice(0, 4)}-${s.slice(4)}`;
}
