/**
 * Venue seat-layout generator.
 * Layouts mirror how real multiplexes and arenas are laid out: lettered rows
 * front-to-back, a centre aisle, and a premium block at the rear of a cinema
 * (closest to the optimal viewing angle) versus at the front of an arena.
 */
export type RowSpec = {
  rowLabel: string;
  seats: number;
  category: string;
  /** 1-based grid columns left blank to render an aisle. */
  aisleAfter?: number[];
};

export type VenueLayout = {
  name: string;
  city: string;
  address: string;
  categories: { name: string; colour: string; rank: number }[];
  rows: RowSpec[];
};

const cinemaRows = (
  spec: { label: string; seats: number; category: string }[],
  aisleAfter: number[],
): RowSpec[] => spec.map((s) => ({ rowLabel: s.label, seats: s.seats, category: s.category, aisleAfter }));

export const VENUE_LAYOUTS: VenueLayout[] = [
  {
    name: 'PVR ICON — Phoenix Palladium',
    city: 'Mumbai',
    address: '462 Senapati Bapat Marg, Lower Parel, Mumbai 400013',
    categories: [
      { name: 'Recliner', colour: '#c084fc', rank: 0 },
      { name: 'Premium', colour: '#f5c518', rank: 1 },
      { name: 'Standard', colour: '#4f7cff', rank: 2 },
    ],
    rows: cinemaRows(
      [
        { label: 'A', seats: 14, category: 'Standard' },
        { label: 'B', seats: 14, category: 'Standard' },
        { label: 'C', seats: 16, category: 'Standard' },
        { label: 'D', seats: 16, category: 'Standard' },
        { label: 'E', seats: 16, category: 'Premium' },
        { label: 'F', seats: 16, category: 'Premium' },
        { label: 'G', seats: 16, category: 'Premium' },
        { label: 'H', seats: 12, category: 'Recliner' },
        { label: 'J', seats: 12, category: 'Recliner' },
      ],
      [4, 12],
    ),
  },
  {
    name: 'INOX — Nariman Point',
    city: 'Mumbai',
    address: '143 Marine Drive, Nariman Point, Mumbai 400021',
    categories: [
      { name: 'Premium', colour: '#f5c518', rank: 0 },
      { name: 'Standard', colour: '#4f7cff', rank: 1 },
    ],
    rows: cinemaRows(
      [
        { label: 'A', seats: 12, category: 'Standard' },
        { label: 'B', seats: 12, category: 'Standard' },
        { label: 'C', seats: 14, category: 'Standard' },
        { label: 'D', seats: 14, category: 'Standard' },
        { label: 'E', seats: 14, category: 'Premium' },
        { label: 'F', seats: 14, category: 'Premium' },
        { label: 'G', seats: 10, category: 'Premium' },
      ],
      [3, 11],
    ),
  },
  {
    name: 'Cinepolis — Nexus Koramangala',
    city: 'Bengaluru',
    address: '20 Hosur Main Road, Koramangala, Bengaluru 560095',
    categories: [
      { name: 'Premium', colour: '#f5c518', rank: 0 },
      { name: 'Standard', colour: '#4f7cff', rank: 1 },
    ],
    rows: cinemaRows(
      [
        { label: 'A', seats: 13, category: 'Standard' },
        { label: 'B', seats: 13, category: 'Standard' },
        { label: 'C', seats: 15, category: 'Standard' },
        { label: 'D', seats: 15, category: 'Premium' },
        { label: 'E', seats: 15, category: 'Premium' },
        { label: 'F', seats: 15, category: 'Premium' },
      ],
      [4, 12],
    ),
  },
  {
    name: 'Jawaharlal Nehru Stadium — Arena Floor',
    city: 'New Delhi',
    address: 'Pragati Vihar, Lodhi Road, New Delhi 110003',
    categories: [
      { name: 'Golden Circle', colour: '#f5c518', rank: 0 },
      { name: 'Silver', colour: '#a1a8bd', rank: 1 },
      { name: 'General', colour: '#4f7cff', rank: 2 },
    ],
    rows: cinemaRows(
      [
        { label: 'A', seats: 18, category: 'Golden Circle' },
        { label: 'B', seats: 18, category: 'Golden Circle' },
        { label: 'C', seats: 20, category: 'Silver' },
        { label: 'D', seats: 20, category: 'Silver' },
        { label: 'E', seats: 22, category: 'General' },
        { label: 'F', seats: 22, category: 'General' },
        { label: 'G', seats: 22, category: 'General' },
      ],
      [6, 16],
    ),
  },
];

/** Expand a layout into concrete seat records with grid coordinates (aisles left empty). */
export function expandLayout(layout: VenueLayout) {
  const seats: { rowLabel: string; seatNumber: number; gridRow: number; gridCol: number; category: string }[] = [];
  layout.rows.forEach((row, rIdx) => {
    let col = 1;
    for (let n = 1; n <= row.seats; n++) {
      if (row.aisleAfter?.includes(n - 1)) col += 1; // blank column = aisle
      seats.push({ rowLabel: row.rowLabel, seatNumber: n, gridRow: rIdx + 1, gridCol: col, category: row.category });
      col += 1;
    }
  });
  return seats;
}
