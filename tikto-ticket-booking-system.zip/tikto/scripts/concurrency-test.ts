/**
 * Proves the concurrency guarantee against a live database.
 *
 *   npm run test:concurrency
 *
 * Fires N simultaneous hold attempts at the SAME seats and asserts that
 * exactly one succeeds. Then verifies TTL auto-release, and that a lapsed
 * hold is immediately re-holdable by someone else.
 */
import 'dotenv/config';
import { prisma } from '../src/lib/prisma';
import { holdSeats, releaseHold, sweepExpiredHolds, getSeatMap } from '../src/lib/seats';

const CONTENDERS = 20;

function assert(cond: boolean, msg: string) {
  if (!cond) {
    console.error(`✗ ${msg}`);
    process.exitCode = 1;
  } else {
    console.log(`✓ ${msg}`);
  }
}

async function main() {
  const show = await prisma.show.findFirst({
    where: { startsAt: { gte: new Date() }, showSeats: { some: { state: 'AVAILABLE' } } },
    orderBy: { startsAt: 'asc' },
  });
  if (!show) throw new Error('No upcoming show with free seats — run `npm run db:seed` first.');

  const free = await prisma.showSeat.findMany({
    where: { showId: show.id, state: 'AVAILABLE' },
    take: 3,
    select: { seatId: true },
  });
  const seatIds = free.map((f) => f.seatId);
  console.log(`\nshow ${show.id} — contesting seats ${seatIds.join(', ')} with ${CONTENDERS} parallel requests\n`);

  // ---- 1. Simultaneous holds on identical seats -----------------------------
  const results = await Promise.allSettled(
    Array.from({ length: CONTENDERS }, () => holdSeats({ showId: show.id, seatIds, ttlSeconds: 30 })),
  );
  const won = results.filter((r) => r.status === 'fulfilled');
  const lost = results.filter((r) => r.status === 'rejected');
  assert(won.length === 1, `exactly one request won the seats (won=${won.length}, lost=${lost.length})`);

  const heldRows = await prisma.showSeat.count({ where: { showId: show.id, seatId: { in: seatIds }, state: 'HELD' } });
  assert(heldRows === seatIds.length, `all ${seatIds.length} seats are HELD by a single hold id`);

  const distinctHolds = await prisma.showSeat.findMany({
    where: { showId: show.id, seatId: { in: seatIds } },
    select: { holdId: true },
    distinct: ['holdId'],
  });
  assert(distinctHolds.length === 1, 'the seats share one hold id — no partial/split hold');

  // ---- 2. Partial overlap must not half-succeed -----------------------------
  const otherFree = await prisma.showSeat.findFirst({
    where: { showId: show.id, state: 'AVAILABLE' },
    select: { seatId: true },
  });
  if (otherFree) {
    const overlap = await Promise.allSettled([
      holdSeats({ showId: show.id, seatIds: [seatIds[0], otherFree.seatId], ttlSeconds: 30 }),
    ]);
    assert(overlap[0].status === 'rejected', 'a request overlapping a held seat is rejected entirely');
    const stillFree = await prisma.showSeat.findUnique({
      where: { showId_seatId: { showId: show.id, seatId: otherFree.seatId } },
    });
    assert(stillFree?.state === 'AVAILABLE', 'the non-contested seat in that request was NOT left stranded');
  }

  // ---- 3. TTL expiry ---------------------------------------------------------
  const winner = (won[0] as PromiseFulfilledResult<Awaited<ReturnType<typeof holdSeats>>>).value;
  await prisma.showSeat.updateMany({
    where: { holdId: winner.holdId },
    data: { holdExpiresAt: new Date(Date.now() - 1000) },
  });

  const map = await getSeatMap(show.id);
  const lapsedLookFree = seatIds.every((id) => map.seats.find((s) => s.seatId === id)?.state === 'AVAILABLE');
  assert(lapsedLookFree, 'a lapsed hold reads as AVAILABLE even before the sweeper runs (lazy expiry)');

  const rehold = await holdSeats({ showId: show.id, seatIds, ttlSeconds: 30 });
  assert(!!rehold.holdId, 'another customer can immediately hold seats whose TTL lapsed');

  const swept = await sweepExpiredHolds();
  console.log(`  (sweeper reclaimed ${swept.released} stale row(s))`);

  await releaseHold(rehold.holdId);
  const finallyFree = await prisma.showSeat.count({
    where: { showId: show.id, seatId: { in: seatIds }, state: 'AVAILABLE' },
  });
  assert(finallyFree === seatIds.length, 'explicit release puts every seat back on sale');

  console.log(process.exitCode ? '\nSOME CHECKS FAILED\n' : '\nAll concurrency checks passed.\n');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
