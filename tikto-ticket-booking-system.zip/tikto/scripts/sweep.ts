/**
 * Standalone TTL worker — an alternative to the /api/cron/sweep HTTP endpoint
 * for hosts without a cron product (Render/Railway background worker):
 *
 *   npm run sweep            # loop forever, every 30s
 *   npm run sweep -- --once  # single pass, for an external scheduler
 */
import 'dotenv/config';
import { sweepExpiredHolds } from '../src/lib/seats';
import { expireLapsedOffers } from '../src/lib/waitlist';
import { prisma } from '../src/lib/prisma';

const INTERVAL_MS = Number(process.env.SWEEP_INTERVAL_MS || 30_000);

async function pass() {
  const offers = await expireLapsedOffers();
  const holds = await sweepExpiredHolds();
  if (holds.released || offers.expired || offers.reoffered) {
    console.log(
      `[sweep ${new Date().toISOString()}] holds released=${holds.released} offers expired=${offers.expired} re-offered=${offers.reoffered}`,
    );
  }
}

async function main() {
  const once = process.argv.includes('--once');
  console.log(once ? 'running a single sweep' : `sweeping every ${INTERVAL_MS / 1000}s — ctrl-c to stop`);
  await pass();
  if (once) return prisma.$disconnect();
  setInterval(() => pass().catch((e) => console.error('[sweep] failed', e)), INTERVAL_MS);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
