# Tikto — System Design Write-up

*Seat hold & TTL · concurrency prevention · waitlist auto-assignment · time-limited offers*

## The core decision

Everything in this system follows from one choice: **make the database the only arbiter of seat state.**
A `ShowSeat` row is materialised for every (show, seat) pair when a show is created, and each row carries
`state`, `holdId` and `holdExpiresAt`. Availability is never derived by counting bookings, because a
derived value cannot be locked. With a concrete row per seat, every transition becomes a single atomic
statement, and correctness survives multiple serverless instances, restarts and skewed clocks.

## Seat hold and the TTL mechanism

Selecting seats issues a hold: `state='HELD'`, `holdId` = a UUID naming the checkout session, and
`holdExpiresAt = NOW() + SEAT_HOLD_TTL_SECONDS` (default 600). Those three columns are written together, so
a hold cannot exist without an owner or a deadline. The timestamp comes from Postgres `NOW()`, never a Node
clock.

Expiry is deliberately **lazy**. Both sides of the system treat a lapsed lock as free:

- the seat map reports a `HELD` seat whose `holdExpiresAt` has passed as `AVAILABLE`;
- the hold statement itself accepts `state='AVAILABLE' OR (state IN ('HELD','OFFERED') AND holdExpiresAt < NOW())`.

This is the important property: **the scheduler is housekeeping, not correctness.** If the sweeper dies, no
seat is ever wrongly withheld from sale — the worst outcome is a seat looking taken for a few extra seconds
on a client that hasn't polled. Compare a design where a cron job is the only thing that frees seats: a
failed job silently strands inventory during exactly the sell-out that motivated the feature.

`/api/cron/sweep` (Vercel Cron, every minute) or the `npm run sweep` worker then normalises rows and, more
importantly, drives waitlist re-offers, which lazy expiry alone cannot do. Abandoning checkout in the UI
calls `DELETE /api/holds/:id` for an instant release rather than waiting out the TTL.

## Concurrency prevention

Each transition is one conditional `UPDATE` whose `WHERE` clause *is* its precondition:

```sql
UPDATE show_seats SET state='HELD', "holdId"=$1, "holdExpiresAt"=$2
 WHERE "showId"=$3 AND "seatId" IN ($4…)
   AND (state='AVAILABLE' OR (state IN ('HELD','OFFERED') AND "holdExpiresAt" < NOW()));
```

Postgres locks each row before evaluating the predicate. Two requests for seat H7 serialise: the first
flips it; the second blocks, re-reads the row under READ COMMITTED, no longer matches, and updates zero
rows. No application mutex, no Redis, no second source of truth that can disagree with the database.

Multi-seat requests need one more step. The code compares `rowsUpdated` with the number of seats requested;
a partial match means another customer won at least one seat, so it throws and the surrounding transaction
rolls back. **Holds are all-or-nothing** — a party of four never ends up with two seats and a stranded pair
that nobody can use. `@@unique([showId, seatId])` keeps the table itself honest.

The only genuine retry case is a deadlock from two overlapping seat sets locked in opposite scan order.
`withRetry()` retries on SQLSTATE `40P01`/`40001` **only** — never on a business rejection, so a losing
customer is never quietly handed a seat on retry. Committing a booking runs the same pattern with
`AND holdExpiresAt > NOW()`, so a checkout submitted one second late fails cleanly with `410` instead of
double-selling.

## Waitlist auto-assignment

`WaitlistEntry` is a FIFO queue per (show, seat category), ordered by a `position` allocated inside a
transaction, with a unique constraint preventing double-queueing. When a booking is cancelled, its seats
are freed inside that same transaction, and `offerFreedSeats()` then walks each seat: read its category,
take the lowest-`position` `WAITING` entry, and conditionally flip the seat to `OFFERED` with
`holdId = offerToken` and its own expiry. If that update touches zero rows a walk-in customer got there
first — the entry simply stays queued rather than erroring.

The offer email is sent **after** the transaction commits. A mail-provider outage must never un-reserve a
seat that the database has already reserved; the reverse (a reserved seat whose email failed) self-heals
when the offer lapses.

## Time-limited offers

`OFFERED` reuses the same `holdId`/`holdExpiresAt` columns as a checkout hold. That single decision means
the sweeper, the seat map and the booking commit need no waitlist special-casing at all — and because the
offer token *is* the hold id, claiming an offer runs the ordinary booking commit rather than a parallel code
path that could drift out of sync.

`expireLapsedOffers()` marks lapsed entries `EXPIRED`, releases their seats and immediately calls
`offerFreedSeats()` again, so a seat walks down the queue on its own until someone claims it or the queue
empties. Every step writes an `AuditLog` row, which is what makes an automated allocation defensible when a
customer asks why they didn't get the seat.

*(≈780 words)*
