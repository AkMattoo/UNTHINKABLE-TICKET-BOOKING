import type { Config } from 'tailwindcss';
const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0b0d12', panel: '#141821', line: '#232936',
        accent: '#f5c518', muted: '#8b93a7',
      },
    },
  },
  plugins: [],
};
export default config;
