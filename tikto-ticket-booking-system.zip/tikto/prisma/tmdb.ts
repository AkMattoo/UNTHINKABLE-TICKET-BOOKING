/**
 * TMDB ingestion for the seeder.
 *
 * With TMDB_API_KEY set, we pull the live "now playing" list (region IN) plus
 * genre names, so the catalogue is real, current cinema data.
 * Without a key, we fall back to the bundled catalogue below so `db:seed`
 * still produces a realistic, fully working dataset with zero signup.
 */
export type SeedMovie = {
  title: string;
  overview: string;
  posterUrl: string | null;
  language: string;
  genre: string;
  runtime: number;
  certificate: string;
  externalId?: string;
};

const IMG = 'https://image.tmdb.org/t/p/w500';

export const FALLBACK_MOVIES: SeedMovie[] = [
  {
    title: 'Dune: Part Two',
    overview:
      'Paul Atreides unites with the Fremen to wage war against House Harkonnen, torn between the love of his life and the fate of the known universe.',
    posterUrl: null,
    language: 'English',
    genre: 'Science Fiction, Adventure',
    runtime: 167,
    certificate: 'UA',
    externalId: '693134',
  },
  {
    title: 'Oppenheimer',
    overview:
      'The story of J. Robert Oppenheimer and the Manhattan Project — the scientist who became the father of the atomic bomb, and then had to live with it.',
    posterUrl: null,
    language: 'English',
    genre: 'Drama, History',
    runtime: 181,
    certificate: 'A',
    externalId: '872585',
  },
  {
    title: 'Spider-Man: Across the Spider-Verse',
    overview:
      'Miles Morales is catapulted across the multiverse, where he encounters a team of Spider-People charged with protecting its very existence.',
    posterUrl: null,
    language: 'English',
    genre: 'Animation, Action',
    runtime: 140,
    certificate: 'U',
    externalId: '569094',
  },
  {
    title: '12th Fail',
    overview:
      'Based on the true story of IPS officer Manoj Kumar Sharma, who restarted his life after failing his 12th standard exams and cleared the UPSC.',
    posterUrl: null,
    language: 'Hindi',
    genre: 'Drama, Biography',
    runtime: 147,
    certificate: 'U',
    externalId: '1049083',
  },
  {
    title: 'Everything Everywhere All at Once',
    overview:
      'An ageing Chinese immigrant is swept up in an insane adventure in which she alone can save existence by exploring other universes.',
    posterUrl: null,
    language: 'English',
    genre: 'Action, Comedy',
    runtime: 139,
    certificate: 'A',
    externalId: '545611',
  },
  {
    title: 'Interstellar',
    overview:
      'A team of explorers travel through a wormhole in space in an attempt to ensure humanity’s survival.',
    posterUrl: null,
    language: 'English',
    genre: 'Science Fiction, Drama',
    runtime: 169,
    certificate: 'UA',
    externalId: '157336',
  },
  {
    title: 'RRR',
    overview:
      'A fictitious story about two legendary revolutionaries and their journey away from home before they began fighting for their country in the 1920s.',
    posterUrl: null,
    language: 'Telugu',
    genre: 'Action, Drama',
    runtime: 187,
    certificate: 'UA',
    externalId: '579974',
  },
  {
    title: 'Laapataa Ladies',
    overview:
      'Two young brides are swapped by accident on a train, and the mix-up sets off a warm, sharp comedy about the lives women are handed.',
    posterUrl: null,
    language: 'Hindi',
    genre: 'Comedy, Drama',
    runtime: 122,
    certificate: 'U',
    externalId: '1053626',
  },
];

export const CONCERTS: SeedMovie[] = [
  {
    title: 'Coldplay — Music of the Spheres World Tour',
    overview:
      'The Music of the Spheres tour brings the full LED-wristband spectacle, a career-spanning setlist and a stadium-scale light show.',
    posterUrl: null,
    language: 'English',
    genre: 'Rock, Pop',
    runtime: 150,
    certificate: 'U',
  },
  {
    title: 'A. R. Rahman — Live in Concert',
    overview:
      'A full orchestra and a rotating cast of vocalists perform three decades of film scores, from Roja to Rockstar.',
    posterUrl: null,
    language: 'Multiple',
    genre: 'Film Score, Fusion',
    runtime: 180,
    certificate: 'U',
  },
  {
    title: 'Diljit Dosanjh — Dil-Luminati Tour',
    overview: 'A stadium Punjabi-pop show built around the Dil-Luminati record, with a live band and full production.',
    posterUrl: null,
    language: 'Punjabi',
    genre: 'Pop, Bhangra',
    runtime: 135,
    certificate: 'U',
  },
];

type TmdbMovie = {
  id: number;
  title: string;
  overview: string;
  poster_path: string | null;
  original_language: string;
  genre_ids: number[];
  adult: boolean;
};

const LANGS: Record<string, string> = {
  en: 'English', hi: 'Hindi', ta: 'Tamil', te: 'Telugu', ml: 'Malayalam',
  kn: 'Kannada', mr: 'Marathi', bn: 'Bengali', pa: 'Punjabi', ja: 'Japanese', ko: 'Korean',
};

export async function fetchTmdbNowPlaying(apiKey: string, limit = 10): Promise<SeedMovie[]> {
  const genreRes = await fetch(`https://api.themoviedb.org/3/genre/movie/list?api_key=${apiKey}&language=en-US`);
  if (!genreRes.ok) throw new Error(`TMDB genre list failed: ${genreRes.status}`);
  const genreJson = (await genreRes.json()) as { genres: { id: number; name: string }[] };
  const genreName = new Map(genreJson.genres.map((g) => [g.id, g.name]));

  const res = await fetch(
    `https://api.themoviedb.org/3/movie/now_playing?api_key=${apiKey}&language=en-US&region=IN&page=1`,
  );
  if (!res.ok) throw new Error(`TMDB now_playing failed: ${res.status}`);
  const json = (await res.json()) as { results: TmdbMovie[] };

  const picks = json.results.slice(0, limit);
  const detailed: SeedMovie[] = [];

  for (const m of picks) {
    let runtime = 130;
    try {
      const d = await fetch(`https://api.themoviedb.org/3/movie/${m.id}?api_key=${apiKey}`);
      if (d.ok) runtime = (await d.json()).runtime || 130;
    } catch {
      /* keep the default */
    }
    detailed.push({
      title: m.title,
      overview: m.overview || 'No synopsis available.',
      posterUrl: m.poster_path ? `${IMG}${m.poster_path}` : null,
      language: LANGS[m.original_language] ?? m.original_language.toUpperCase(),
      genre: m.genre_ids.map((g) => genreName.get(g)).filter(Boolean).join(', ') || 'Drama',
      runtime,
      certificate: m.adult ? 'A' : 'UA',
      externalId: String(m.id),
    });
  }
  return detailed;
}
