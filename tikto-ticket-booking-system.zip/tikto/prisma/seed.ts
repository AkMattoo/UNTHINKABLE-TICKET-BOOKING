import 'dotenv/config';
import { PrismaClient, EventType, Role } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { VENUE_LAYOUTS, expandLayout } from '../src/lib/layout';
import { CONCERTS, FALLBACK_MOVIES, fetchTmdbNowPlaying, type SeedMovie } from './tmdb';

const prisma = new PrismaClient();

const SHOW_TIMES = ['10:15', '13:30', '17:00', '20:45'];
const PRICE_TABLE: Record<string, number> = {
  Recliner: 65000, Premium: 38000, Standard: 22000,
  'Golden Circle': 1200000, Silver: 650000, General: 350000,
};

function atLocal(dayOffset: number, hhmm: string) {
  const [h, m] = hhmm.split(':').map(Number);
  const d = new Date();
  d.setDate(d.getDate() + dayOffset);
  d.setHours(h, m, 0, 0);
  return d;
}

async function main() {
  console.log('› clearing existing data');
  await prisma.auditLog.deleteMany();
  await prisma.waitlistEntry.deleteMany();
  await prisma.showSeat.deleteMany();
  await prisma.booking.deleteMany();
  await prisma.showPrice.deleteMany();
  await prisma.show.deleteMany();
  await prisma.event.deleteMany();
  await prisma.seat.deleteMany();
  await prisma.seatCategory.deleteMany();
  await prisma.venue.deleteMany();
  await prisma.user.deleteMany();

  console.log('› creating users');
  const pw = await bcrypt.hash('Password123!', 10);
  const admin = await prisma.user.create({
    data: { email: 'admin@tikto.dev', name: 'Asha Menon', passwordHash: pw, role: Role.ADMIN },
  });
  const organiser = await prisma.user.create({
    data: { email: 'organiser@tikto.dev', name: 'Rohan Iyer', passwordHash: pw, role: Role.ORGANISER },
  });
  const customers = await Promise.all(
    [
      ['customer@tikto.dev', 'Priya Nair'],
      ['rahul@tikto.dev', 'Rahul Verma'],
      ['sana@tikto.dev', 'Sana Qureshi'],
      ['dev@tikto.dev', 'Dev Kulkarni'],
    ].map(([email, name]) =>
      prisma.user.create({ data: { email, name, passwordHash: pw, role: Role.CUSTOMER } }),
    ),
  );

  console.log('› creating venues and seat layouts');
  type SeededVenue = Awaited<ReturnType<typeof prisma.venue.create>> & {
    categories: { id: string; name: string }[];
    seatCount: number;
  };
  const venues: SeededVenue[] = [];
  for (const layout of VENUE_LAYOUTS) {
    const venue = await prisma.venue.create({
      data: {
        name: layout.name,
        city: layout.city,
        address: layout.address,
        categories: { create: layout.categories },
      },
      include: { categories: true },
    });
    const catId = new Map(venue.categories.map((c) => [c.name, c.id]));
    const seats = expandLayout(layout).map((s) => ({
      venueId: venue.id,
      categoryId: catId.get(s.category)!,
      rowLabel: s.rowLabel,
      seatNumber: s.seatNumber,
      gridRow: s.gridRow,
      gridCol: s.gridCol,
    }));
    await prisma.seat.createMany({ data: seats });
    venues.push({ ...venue, seatCount: seats.length });
    console.log(`  · ${venue.name} — ${seats.length} seats, ${venue.categories.length} categories`);
  }

  console.log('› loading catalogue');
  let movies: SeedMovie[] = FALLBACK_MOVIES;
  const key = process.env.TMDB_API_KEY;
  if (key) {
    try {
      movies = await fetchTmdbNowPlaying(key, 10);
      console.log(`  · pulled ${movies.length} live titles from TMDB (now playing, region IN)`);
    } catch (e) {
      console.warn('  ! TMDB fetch failed, using the bundled catalogue:', (e as Error).message);
    }
  } else {
    console.log('  · TMDB_API_KEY not set — using the bundled catalogue of real titles');
  }

  const cinemas = venues.filter((v) => !v.name.includes('Stadium'));
  const arenas = venues.filter((v) => v.name.includes('Stadium'));

  const makeEvent = (m: SeedMovie, type: EventType) =>
    prisma.event.create({
      data: {
        organiserId: organiser.id,
        type,
        title: m.title,
        description: m.overview,
        posterUrl: m.posterUrl,
        language: m.language,
        genre: m.genre,
        durationMin: m.runtime,
        certificate: m.certificate,
        externalId: m.externalId,
      },
    });

  let showCount = 0;
  let seatRowCount = 0;

  async function createShow(eventId: string, venue: SeededVenue, startsAt: Date, screen: string) {
    const show = await prisma.show.create({ data: { eventId, venueId: venue.id, startsAt, screen } });
    await prisma.showPrice.createMany({
      data: venue.categories.map((c) => ({
        showId: show.id,
        categoryId: c.id,
        priceCents: PRICE_TABLE[c.name] ?? 25000,
      })),
    });
    const seats = await prisma.seat.findMany({ where: { venueId: venue.id }, select: { id: true } });
    await prisma.showSeat.createMany({ data: seats.map((s) => ({ showId: show.id, seatId: s.id })) });
    showCount++;
    seatRowCount += seats.length;
    return show;
  }

  console.log('› creating movie shows');
  for (const [i, m] of movies.entries()) {
    const ev = await makeEvent(m, EventType.MOVIE);
    const venue = cinemas[i % cinemas.length];
    for (let day = 0; day < 3; day++) {
      for (const t of SHOW_TIMES.slice(0, day === 0 ? 2 : 4)) {
        const when = atLocal(day + (day === 0 ? 1 : 1), t);
        await createShow(ev.id, venue, when, `Screen ${(i % 4) + 1}`);
      }
    }
  }

  console.log('› creating concerts');
  for (const [i, c] of CONCERTS.entries()) {
    const ev = await makeEvent(c, EventType.CONCERT);
    const venue = arenas[0];
    await createShow(ev.id, venue, atLocal(7 + i * 3, '19:30'), 'Arena Floor');
  }

  // ---- Demo state: one sold-out show with a live waitlist, so the flow is visible immediately.
  console.log('› building a sold-out show with a waitlist for the demo');
  const demoShow = await prisma.show.findFirst({
    where: { event: { type: EventType.MOVIE } },
    orderBy: { startsAt: 'asc' },
    include: { venue: { include: { categories: true } } },
  });
  if (demoShow) {
    const premium = demoShow.venue.categories.find((c) => c.name === 'Premium') ?? demoShow.venue.categories[0];
    const premiumSeats = await prisma.seat.findMany({
      where: { venueId: demoShow.venueId, categoryId: premium.id },
      take: 8,
    });
    const price = PRICE_TABLE[premium.name] ?? 25000;

    const booking = await prisma.booking.create({
      data: {
        reference: 'TKT-DEMO-0001',
        userId: customers[0].id,
        showId: demoShow.id,
        status: 'CONFIRMED',
        totalCents: price * premiumSeats.length,
        seatCount: premiumSeats.length,
        contactName: customers[0].name,
        contactEmail: customers[0].email,
        confirmedAt: new Date(),
      },
    });
    await prisma.showSeat.updateMany({
      where: { showId: demoShow.id, seatId: { in: premiumSeats.map((s) => s.id) } },
      data: { state: 'BOOKED', bookingId: booking.id },
    });
    // Take the rest of that category out of sale so it reads as sold out.
    const rest = await prisma.seat.findMany({
      where: { venueId: demoShow.venueId, categoryId: premium.id, id: { notIn: premiumSeats.map((s) => s.id) } },
    });
    await prisma.showSeat.updateMany({
      where: { showId: demoShow.id, seatId: { in: rest.map((s) => s.id) } },
      data: { state: 'BOOKED' },
    });

    await prisma.waitlistEntry.createMany({
      data: customers.slice(1).map((c, idx) => ({
        showId: demoShow.id,
        categoryId: premium.id,
        userId: c.id,
        position: idx + 1,
        status: 'WAITING' as const,
      })),
    });
    console.log(`  · ${demoShow.id} — ${premium.name} sold out, ${customers.length - 1} people waitlisted`);
    console.log(`  · cancel booking TKT-DEMO-0001 as ${customers[0].email} to watch auto-assignment fire`);
  }

  console.log('\n✔ seed complete');
  console.table({
    users: await prisma.user.count(),
    venues: venues.length,
    seats: await prisma.seat.count(),
    events: await prisma.event.count(),
    shows: showCount,
    showSeatRows: seatRowCount,
    waitlisted: await prisma.waitlistEntry.count(),
  });
  console.log('\nLogins (password for all: Password123!)');
  console.log(`  admin      ${admin.email}`);
  console.log(`  organiser  ${organiser.email}`);
  customers.forEach((c) => console.log(`  customer   ${c.email}`));
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
